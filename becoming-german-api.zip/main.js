/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ([
/* 0 */,
/* 1 */
/***/ ((module) => {

module.exports = require("@nestjs/common");

/***/ }),
/* 2 */
/***/ ((module) => {

module.exports = require("@nestjs/core");

/***/ }),
/* 3 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AppModule = void 0;
const tslib_1 = __webpack_require__(4);
const common_1 = __webpack_require__(1);
const app_controller_1 = __webpack_require__(5);
const api_lib_1 = __webpack_require__(6);
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = tslib_1.__decorate([
    (0, common_1.Module)({
        imports: [],
        controllers: [app_controller_1.AppController],
        providers: [{ provide: api_lib_1.PersonService, useClass: api_lib_1.PersonService }],
    })
], AppModule);


/***/ }),
/* 4 */
/***/ ((module) => {

module.exports = require("tslib");

/***/ }),
/* 5 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AppController = void 0;
const tslib_1 = __webpack_require__(4);
const common_1 = __webpack_require__(1);
const api_lib_1 = __webpack_require__(6);
const t = tslib_1.__importStar(__webpack_require__(16));
const function_1 = __webpack_require__(10);
const Either_1 = __webpack_require__(12);
const model_1 = __webpack_require__(17);
const PathReporter_1 = __webpack_require__(77);
const rxjs_1 = __webpack_require__(75);
const express_1 = __webpack_require__(79);
const getReqC = t.type({
    offset: model_1.NumberFromStringOrNumber,
    limit: (0, model_1.NumberInRange)(1, 500),
});
const decodeOrDefault = (c, def) => (0, function_1.flow)(c.decode, (0, Either_1.fold)(() => def, (v) => v));
const defaultParams = { offset: 0, limit: 10 };
const getParamParser = decodeOrDefault(getReqC, defaultParams);
let AppController = class AppController {
    constructor(service) {
        this.service = service;
        this.results = new rxjs_1.Subject();
    }
    hello() {
        return 'hello world!';
    }
    async getData(params) {
        const { offset, limit } = getParamParser({ ...defaultParams, ...params });
        return this.service.getNormalizedData(offset, limit);
    }
    async getChildhoodRequest(request) {
        const profile = model_1.ChildhoodProfile.decode(request);
        if ((0, Either_1.isRight)(profile)) {
            const table = api_lib_1.ChildhoodProfileTable.decode(profile.right);
            if ((0, Either_1.isRight)(table)) {
                return this.service.findMatchingItem(table.right);
            }
            else
                throw PathReporter_1.PathReporter.report(table);
        }
        console.log('decoding profile did not work', console);
        throw PathReporter_1.PathReporter.report(profile);
    }
    migrate(response) {
        const gen = this.service.normalise(0, 100);
        response.setHeader('Content-Type', 'application/json');
        const createFrom = (asyncCollection) => {
            return new rxjs_1.Observable((subscriber) => {
                (async () => {
                    try {
                        for await (const value of asyncCollection()) {
                            subscriber.next(value);
                            // if(value[value.length-1].id > 100) break;
                        }
                        subscriber.complete();
                        console.log('subscription completed');
                    }
                    catch (err) {
                        subscriber.error(err);
                    }
                })();
            });
        };
        createFrom(gen).subscribe({
            next: (rows) => response.write(JSON.stringify(rows)),
            complete: () => {
                console.log('complete has been called on migration');
                response.end();
            },
            error: (e) => {
                console.error(e);
                response.end();
            }
        });
    }
};
exports.AppController = AppController;
tslib_1.__decorate([
    (0, common_1.Get)('hello'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", []),
    tslib_1.__metadata("design:returntype", void 0)
], AppController.prototype, "hello", null);
tslib_1.__decorate([
    (0, common_1.Get)('admin/profiles/:offset?/:limit?'),
    tslib_1.__param(0, (0, common_1.Param)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [typeof (_b = typeof GetRec !== "undefined" && GetRec) === "function" ? _b : Object]),
    tslib_1.__metadata("design:returntype", Promise)
], AppController.prototype, "getData", null);
tslib_1.__decorate([
    (0, common_1.Post)('request'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], AppController.prototype, "getChildhoodRequest", null);
tslib_1.__decorate([
    (0, common_1.Get)('admin/migrate'),
    tslib_1.__param(0, (0, common_1.Res)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [typeof (_c = typeof express_1.Response !== "undefined" && express_1.Response) === "function" ? _c : Object]),
    tslib_1.__metadata("design:returntype", void 0)
], AppController.prototype, "migrate", null);
exports.AppController = AppController = tslib_1.__decorate([
    (0, common_1.Controller)(),
    tslib_1.__metadata("design:paramtypes", [typeof (_a = typeof api_lib_1.PersonService !== "undefined" && api_lib_1.PersonService) === "function" ? _a : Object])
], AppController);


/***/ }),
/* 6 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(7), exports);


/***/ }),
/* 7 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DbSafeString = void 0;
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(8), exports);
tslib_1.__exportStar(__webpack_require__(62), exports);
tslib_1.__exportStar(__webpack_require__(15), exports);
tslib_1.__exportStar(__webpack_require__(61), exports);
tslib_1.__exportStar(__webpack_require__(67), exports);
tslib_1.__exportStar(__webpack_require__(71), exports);
tslib_1.__exportStar(__webpack_require__(70), exports);
tslib_1.__exportStar(__webpack_require__(66), exports);
tslib_1.__exportStar(__webpack_require__(78), exports);
tslib_1.__exportStar(__webpack_require__(68), exports);
tslib_1.__exportStar(__webpack_require__(47), exports);
tslib_1.__exportStar(__webpack_require__(69), exports);
var db_safe_string_1 = __webpack_require__(63);
Object.defineProperty(exports, "DbSafeString", ({ enumerable: true, get: function () { return db_safe_string_1.DbSafeString; } }));


/***/ }),
/* 8 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MatchingItemsDBC = exports.PersonService = void 0;
const tslib_1 = __webpack_require__(4);
const promise_1 = __webpack_require__(9);
const function_1 = __webpack_require__(10);
const A = tslib_1.__importStar(__webpack_require__(11));
const Array_1 = __webpack_require__(11);
const E = tslib_1.__importStar(__webpack_require__(12));
const Either_1 = __webpack_require__(12);
const O = tslib_1.__importStar(__webpack_require__(13));
const TE = tslib_1.__importStar(__webpack_require__(14));
const person_table_1 = __webpack_require__(15);
const model_1 = __webpack_require__(17);
const rxjs_1 = __webpack_require__(75);
const book_item_1 = __webpack_require__(66);
const song_item_1 = __webpack_require__(68);
const audio_book_item_1 = __webpack_require__(74);
const party_item_1 = __webpack_require__(73);
const t = tslib_1.__importStar(__webpack_require__(16));
const config_1 = __webpack_require__(76);
const PathReporter_1 = __webpack_require__(77);
// const processEntry = (row: unknown): Either<number, Entry> => {
//   const item = row['jsonItem'];
//   const validationResult = EntryC.decode(item);
//
//   if (isLeft(validationResult)) {
//     const failedPropertyNames = validationResult.left.map((error) => error.context[error.context.length - 1].key);
//
//     console.log('failed parsing', failedPropertyNames);
//   }
//   return pipe(
//     validationResult,
//     mapLeft(() => row['id']),
//   );
// };
const processPerson = (row) => {
    const item = row['json_mapping'];
    const validationResult = person_table_1.PersonTable.decode(item);
    if ((0, Either_1.isLeft)(validationResult)) {
        // const failedPropertyNames = validationResult.left.map((error) => error.context[error.context.length - 1].key);
        console.log('failed parsing', item['id']);
    }
    return (0, function_1.pipe)(validationResult, (0, Either_1.mapLeft)(() => item['id']));
};
const processNormalizedPerson = (row) => {
    const validationResult = model_1.Person.decode(row.jsonData);
    if ((0, Either_1.isLeft)(validationResult)) {
        console.log('failed decoding', PathReporter_1.PathReporter.report(validationResult));
    }
    return (0, function_1.pipe)(validationResult, (0, Either_1.mapLeft)(() => row.id));
};
const itemBitSum = (pt) => model_1.items.reduce((r, i) => (pt[i] != null ? r + model_1.ItemToggleValue[i] : r), 0);
const updateJsonWithPool = (pool) => (person) => {
    return (0, function_1.pipe)(TE.tryCatch(async () => {
        const items_de = itemBitSum(person);
        const sql = `update tbl_german_person SET jsonData = ?, items_de = ?, migrated = 1 WHERE id = ?`;
        const conn = await pool.getConnection();
        await conn.execute(sql, [JSON.stringify(person), items_de, person.id]);
        conn.release();
        return { id: person.id };
    }, (error) => ({ error, id: person.id })));
};
class PersonService {
    constructor() {
        this.pool = (0, promise_1.createPool)(config_1.dbConfig);
        this.totalRows = new rxjs_1.BehaviorSubject(0);
    }
    async addQuarantined(ids) {
        const conn = await this.pool.getConnection();
        const sql = conn.format(`UPDATE tbl_german_person SET isQuarantined=1 WHERE id in (?)`, [ids]);
        console.log(sql);
        const [upResult] = await conn.execute(sql);
        console.warn(upResult['changedRows'], 'entries in german_person quarantined', ids);
    }
    async getNormalizedData(offset, limit) {
        const conn = await this.pool.getConnection();
        try {
            if (this.totalRows.getValue() === 0)
                this.totalRows.next((await conn.execute(person_table_1.countPersonSql))[0][0]['total']);
            const sql = (0, person_table_1.getNormalizePersonSql)(offset, limit);
            console.log(sql);
            const res = (0, function_1.pipe)(await conn.execute(sql), (r) => r[0], A.partitionMap(processNormalizedPerson));
            conn.release();
            return {
                status: 'ok',
                total: this.totalRows.getValue(),
                errors: res.left.length,
                offset,
                endId: res.right.length > 0 ? res.right[res.right.length - 1].id : offset,
                result: res.right,
            };
        }
        catch (e) {
            console.error(e);
            return { total: this.totalRows.getValue(), errors: 0, offset, endId: offset, result: [], status: 'error' };
        }
    }
    async getData(offset, limit) {
        const conn = await this.pool.getConnection();
        try {
            if (this.totalRows.getValue() === 0)
                this.totalRows.next((await conn.execute(person_table_1.countPersonSql))[0][0]['total']);
            const res = (0, function_1.pipe)(await conn.execute((0, person_table_1.getPersonSql)(offset, limit)), (r) => r[0], A.partitionMap(processPerson));
            if (res.left.length > 0)
                await this.addQuarantined(res.left);
            conn.release();
            return {
                status: 'ok',
                total: this.totalRows.getValue(),
                errors: res.left.length,
                offset,
                endId: res.right.length > 0 ? res.right[res.right.length - 1].id : offset,
                result: res.right,
            };
        }
        catch (e) {
            console.error(e);
            return { total: this.totalRows.getValue(), errors: 0, offset, endId: offset, result: [], status: 'error' };
        }
    }
    normalise(fromId, limit = 500) {
        const update = updateJsonWithPool(this.pool);
        const getData = (id) => TE.tryCatch(() => this.getData(id, limit), (error) => ({ error, id }));
        const queryToUpdate = (0, function_1.flow)((r) => r.result, A.map(update), A.map(TE.fold(TE.right, TE.right)), A.sequence(TE.ApplicativePar));
        const getRes = async function* (currentId = fromId) {
            const result = await (0, function_1.pipe)(getData(currentId), TE.chain(queryToUpdate))();
            if (E.isLeft(result)) {
                console.log('result is left', result.left);
                yield [];
            }
            else {
                const lastId = (0, Array_1.last)(result.right); // Assuming the last number in the array is the
                if (O.isNone(lastId)) {
                    console.log('last id is null');
                    yield [];
                    return;
                }
                if (lastId.value.error) {
                    console.log('we have an error on', lastId.value.id);
                    yield [];
                    return;
                }
                else {
                    yield result.right;
                    yield* getRes(lastId.value.id);
                }
            }
            return;
        };
        return getRes;
    }
    async findMatchingItem(profile) {
        const exe = async (sql) => {
            const conn = await this.pool.getConnection();
            const [rows] = await conn.execute(sql);
            conn.release();
            return rows;
        };
        const results = (await Promise.all((0, person_table_1.getSearch)(profile).map(exe))).flat();
        console.log(results);
        return processMatchingItem(results);
    }
}
exports.PersonService = PersonService;
exports.MatchingItemsDBC = t.type({
    book: (0, model_1.MatchingItemC)(book_item_1.BookItem),
    grandparents: (0, model_1.MatchingItemC)(model_1.Grandparents),
    holidays: (0, model_1.MatchingItemC)(model_1.Holiday),
    memory: (0, model_1.MatchingItemC)(model_1.Memory),
    party: (0, model_1.MatchingItemC)(party_item_1.PartyItem),
    song: (0, model_1.MatchingItemC)(song_item_1.SongItem),
    speaking_book: (0, model_1.MatchingItemC)(audio_book_item_1.AudioBookItem),
});
const processMatchingItem = (rows) => {
    const dbResult = (0, function_1.pipe)(rows, A.map((r) => r.jsonItem), A.reduce({}, (r, v) => ({ ...r, ...v })));
    const validationResult = exports.MatchingItemsDBC.decode(dbResult);
    if ((0, Either_1.isRight)(validationResult))
        return validationResult.right;
    if ((0, Either_1.isLeft)(validationResult)) {
        // console.log('failed parsing', item);
        console.error(`Validation failed! on ${JSON.stringify(dbResult)}`, validationResult.left.map((error) => error.context[error.context.length - 1].key));
    }
    return null;
};


/***/ }),
/* 9 */
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),
/* 10 */
/***/ ((module) => {

module.exports = require("fp-ts/function");

/***/ }),
/* 11 */
/***/ ((module) => {

module.exports = require("fp-ts/Array");

/***/ }),
/* 12 */
/***/ ((module) => {

module.exports = require("fp-ts/Either");

/***/ }),
/* 13 */
/***/ ((module) => {

module.exports = require("fp-ts/Option");

/***/ }),
/* 14 */
/***/ ((module) => {

module.exports = require("fp-ts/TaskEither");

/***/ }),
/* 15 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getSearch = exports.getPersonSql = exports.getNormalizePersonSql = exports.countPersonSql = exports.PersonTable = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
const model_1 = __webpack_require__(17);
const field_mapping_1 = __webpack_require__(61);
const childhood_profile_table_1 = __webpack_require__(62);
const function_1 = __webpack_require__(10);
const Record_1 = __webpack_require__(65);
const A = tslib_1.__importStar(__webpack_require__(11));
const book_item_1 = __webpack_require__(66);
const song_item_1 = __webpack_require__(68);
const weights_1 = __webpack_require__(69);
const item_query_table_1 = __webpack_require__(70);
const party_item_1 = __webpack_require__(73);
const audio_book_item_1 = __webpack_require__(74);
const itemsProps = {
    book: (0, model_1.NullableTranslatableC)(book_item_1.BookItem),
    grandparents: (0, model_1.NullableTranslatableC)(model_1.Grandparents),
    holidays: (0, model_1.NullableTranslatableC)(model_1.Holiday),
    memory: (0, model_1.NullableTranslatableC)(model_1.Memory),
    party: (0, model_1.NullableTranslatableC)(party_item_1.PartyItem),
    song: (0, model_1.NullableTranslatableC)(song_item_1.SongItem),
    speaking_book: (0, model_1.NullableTranslatableC)(audio_book_item_1.AudioBookItem),
};
exports.PersonTable = t.intersection([
    t.exact(t.type({
        id: t.number,
        dwellingSituationComment: (0, model_1.NullableTranslatableC)(t.string),
        germanState: model_1.germanStateType.fromNumber,
        ...itemsProps
    })),
    childhood_profile_table_1.ChildhoodProfileTable,
]);
const personTableMappingConfig = [
    ['bedroomSituation'],
    ['birthYear', 'DATE_FORMAT(birthDate,"%Y")'],
    ['dwellingSituation'],
    ['dwellingSituationComment'],
    ['parents'],
    ['gender', 'sex'],
    ['germanState'],
    ['id'],
    ['moves', 'homeMoves'],
    ['siblingPosition'],
    ['siblings'],
    ['hobby'],
    ['favoriteColor'],
];
const personTableMapping = personTableMappingConfig.map(([a, b]) => (0, field_mapping_1.fMapping)(a, `p.${b || a}`));
exports.countPersonSql = `SELECT count(*) as total from tbl_german_person WHERE isQuarantined=0`;
const getNormalizePersonSql = (offset = 0, limit = 10) => {
    return `select id, jsonData from tbl_german_person where id > ${offset} AND isQuarantined = false limit ${limit}`;
};
exports.getNormalizePersonSql = getNormalizePersonSql;
const getPersonSql = (offset = 0, limit = 10) => {
    const items = (0, function_1.pipe)(item_query_table_1.itemQueryTable, Record_1.toEntries, A.map(([k, v]) => `'${k}', (
        SELECT ${v} 
        FROM tbl_${k} de_${k} LEFT JOIN eng_tbl_${k} en_${k} ON de_${k}.id=en_${k}.id 
        WHERE de_${k}.pid=p.id LIMIT 1
        )`)).join(',');
    return `
  SELECT json_object(${personTableMapping.join(', ')}, ${items} ) as json_mapping
  FROM tbl_german_person p
  WHERE 
    isQuarantined=0
    AND p.id > ${offset}
  ORDER BY p.id  
  LIMIT ${limit}`;
};
exports.getPersonSql = getPersonSql;
const fieldName = (k) => k === 'gender' ? 'sex' : k === 'moves' ? 'homeMoves' : k;
const getSearch = (p) => {
    const data = childhood_profile_table_1.ChildhoodProfileTable.encode(p);
    const weightField = `
      IF(
      ABS(DATE_FORMAT(birthDate,"%Y")-${p.birthYear}) <= ${weights_1.weights.birthYear}, 
      ${weights_1.weights.birthYear} - ABS(DATE_FORMAT(birthDate,"%Y")-${p.birthYear}), 0)+
      ${Object.entries(weights_1.weights)
        .filter(([k]) => k !== 'birthYear')
        .map(([k, v]) => `if(${fieldName(k)}=${data[k]}, ${v}, 0)`)
        .join('+')}`;
    const divisor = Object.values(weights_1.weights).reduce((r, v) => r + v, 0);
    const getSql = (k) => `
  SELECT p.id, ${weightField} as weight, json_object('${k}', json_object(
  'weight', (${weightField}) / ${divisor} * 100,
  'pid', p.id,
  'item', JSON_EXTRACT(jsonData, '$.${k}'))) as jsonItem
  FROM tbl_german_person p
  WHERE 
  items_de & ${model_1.ItemToggleValue[k]}
  AND  isQuarantined = 0
  ORDER BY weight DESC LIMIT 1`;
    const sql = model_1.items.map((i) => `(${getSql(i)})`);
    //   const sql = `
    //
    //   SELECT p.id, ${weightField} / ${divisor} * 100 as weight, json_object(
    //   'weight', ${weightField} / ${divisor} * 100,
    //   'memory', JSON_OBJECT('de', item.diverse, 'en', eItem.diverse)) as jsonItem
    // FROM tbl_german_person p
    //          JOIN (tbl_memory item LEFT JOIN eng_tbl_memory eItem ON item.id = eItem.id) ON p.id = item.pid
    // WHERE item.id is not null ORDER BY weight DESC LIMIT 1`;
    //   const sql =  pipe(
    //     itemTables,
    //     toEntries,
    //     A.map(
    //       ([item]) =>
    //         `
    //     (SELECT
    //
    //       JSON_OBJECT(
    //
    //       '${item}', (${getItemSql(item)})) as jsonResult
    //       FROM tbl_german_person, ${getItemTableName(item)} b
    //       WHERE b.pid = tbl_german_person.id
    //       AND ${weightField} > 0
    //       ORDER BY weight DESC
    //       limit 1)
    // `,
    //     ),
    //   ).join(' UNION ');
    return sql;
};
exports.getSearch = getSearch;
/*
const t = `
    (SELECT
      (${weightField}) / ${divisor} * 100 as weight,
      JSON_OBJECT(
      'weight',  (${weightField}) / ${divisor} * 100,
      '${item}', (${getItemSql(item)})) as jsonResult
      FROM tbl_german_person, ${getItemTableName(item)} b
      WHERE
      b.pid = tbl_german_person.id
      AND ${weightField} > 0
      ORDER BY weight DESC
      limit 1)
`
 */


/***/ }),
/* 16 */
/***/ ((module) => {

module.exports = require("io-ts");

/***/ }),
/* 17 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(18), exports);


/***/ }),
/* 18 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(19), exports);
tslib_1.__exportStar(__webpack_require__(20), exports);
tslib_1.__exportStar(__webpack_require__(57), exports);


/***/ }),
/* 19 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.decodeOrNull = void 0;
const tslib_1 = __webpack_require__(4);
const function_1 = __webpack_require__(10);
const E = tslib_1.__importStar(__webpack_require__(12));
const decodeOrNull = (codec) => (0, function_1.flow)(codec.decode, E.fold(() => null, (v) => v));
exports.decodeOrNull = decodeOrNull;


/***/ }),
/* 20 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(21), exports);
tslib_1.__exportStar(__webpack_require__(33), exports);
tslib_1.__exportStar(__webpack_require__(34), exports);
tslib_1.__exportStar(__webpack_require__(35), exports);
tslib_1.__exportStar(__webpack_require__(22), exports);
tslib_1.__exportStar(__webpack_require__(36), exports);
tslib_1.__exportStar(__webpack_require__(41), exports);
tslib_1.__exportStar(__webpack_require__(39), exports);
tslib_1.__exportStar(__webpack_require__(44), exports);
tslib_1.__exportStar(__webpack_require__(45), exports);
tslib_1.__exportStar(__webpack_require__(46), exports);
tslib_1.__exportStar(__webpack_require__(42), exports);
tslib_1.__exportStar(__webpack_require__(47), exports);
tslib_1.__exportStar(__webpack_require__(48), exports);
tslib_1.__exportStar(__webpack_require__(53), exports);
tslib_1.__exportStar(__webpack_require__(54), exports);
tslib_1.__exportStar(__webpack_require__(49), exports);
tslib_1.__exportStar(__webpack_require__(40), exports);
tslib_1.__exportStar(__webpack_require__(51), exports);
tslib_1.__exportStar(__webpack_require__(55), exports);
tslib_1.__exportStar(__webpack_require__(56), exports);
tslib_1.__exportStar(__webpack_require__(37), exports);
tslib_1.__exportStar(__webpack_require__(38), exports);
tslib_1.__exportStar(__webpack_require__(50), exports);
tslib_1.__exportStar(__webpack_require__(52), exports);


/***/ }),
/* 21 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AudioBook = exports.audioBookProps = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
const childhood_age_1 = __webpack_require__(22);
exports.audioBookProps = {
    title: t.string,
    author: t.string,
    themeMusic: t.string,
    synopsis: t.string,
    reason: t.string,
    listeningSituation: t.string,
    ageWhenImportant: childhood_age_1.childhoodAgeType.literals,
};
exports.AudioBook = t.exact(t.type(exports.audioBookProps));


/***/ }),
/* 22 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.childhoodAgeType = exports.childhoodAges = void 0;
const tools_1 = __webpack_require__(23);
exports.childhoodAges = ['<5', '5-6', '7-8', '9-10', '10-11', '12-13', '>13'];
exports.childhoodAgeType = (0, tools_1.literalStringArrayTyping)('ChildhoodAge', [...exports.childhoodAges]);


/***/ }),
/* 23 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.literalStringArrayTyping = void 0;
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(24), exports);
tslib_1.__exportStar(__webpack_require__(24), exports);
var literal_string_array_typing_1 = __webpack_require__(29);
Object.defineProperty(exports, "literalStringArrayTyping", ({ enumerable: true, get: function () { return literal_string_array_typing_1.literalStringArrayTyping; } }));


/***/ }),
/* 24 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(25), exports);


/***/ }),
/* 25 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(26), exports);
tslib_1.__exportStar(__webpack_require__(27), exports);
tslib_1.__exportStar(__webpack_require__(29), exports);
tslib_1.__exportStar(__webpack_require__(31), exports);
tslib_1.__exportStar(__webpack_require__(32), exports);


/***/ }),
/* 26 */
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.constArrayValueToNumber = void 0;
const constArrayValueToNumber = (constArray) => (i) => constArray.indexOf(i);
exports.constArrayValueToNumber = constArrayValueToNumber;


/***/ }),
/* 27 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.isInConstArray = void 0;
const string_1 = __webpack_require__(28);
const isInConstArray = (constArray) => {
    return (a) => (0, string_1.isString)(a) && constArray.includes(a);
};
exports.isInConstArray = isInConstArray;


/***/ }),
/* 28 */
/***/ ((module) => {

module.exports = require("fp-ts/string");

/***/ }),
/* 29 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.literalStringArrayTyping = exports.ordFromLiterals = void 0;
const tslib_1 = __webpack_require__(4);
const index_1 = __webpack_require__(25);
const t = tslib_1.__importStar(__webpack_require__(16));
const Ord_1 = __webpack_require__(30);
const isNum = (i) => Number.isInteger(i);
const ordFromLiterals = (constArray) => (0, Ord_1.fromCompare)((a, b) => {
    const idxA = constArray.indexOf(a);
    const idxB = constArray.indexOf(b);
    if (idxA === idxB)
        return 0;
    return idxA > idxB ? 1 : -1;
});
exports.ordFromLiterals = ordFromLiterals;
const literalStringArrayTyping = (typeName, constArray) => {
    const literalArray = t.keyof(constArray.reduce((r, k) => ({ ...r, [k]: null }), {}));
    const fromNumber = new t.Type(`${typeName}FromNumber`, (inp) => literalArray.is(inp) || (isNum(inp) && inp > 0 && inp < constArray.length), (input, context) => {
        if (typeof input === 'string')
            return literalArray.validate(input, context);
        const r = isNum(input) ? (0, index_1.numTo1BasedConst)(constArray)(input) : null;
        return r === null ? t.failure(input, context, `invalid value for ${typeName}`) : t.success(r);
    }, (out) => constArray.indexOf(out) + 1);
    const literals = new t.Type(typeName, fromNumber.is, fromNumber.validate, t.identity);
    return {
        values: constArray,
        guard: (0, index_1.isInConstArray)(constArray),
        fromNumber,
        literals,
        ord: (0, exports.ordFromLiterals)(constArray),
    };
};
exports.literalStringArrayTyping = literalStringArrayTyping;


/***/ }),
/* 30 */
/***/ ((module) => {

module.exports = require("fp-ts/Ord");

/***/ }),
/* 31 */
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.numTo1BasedConst = void 0;
const numTo1BasedConst = (constArray) => (i) => (i < 1 || i > constArray.length) ? null : constArray[i - 1];
exports.numTo1BasedConst = numTo1BasedConst;


/***/ }),
/* 32 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.numberInRange = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
const numberInRange = (min, max) => t.refinement(t.number, (n) => n >= min && n <= max, 'NumberInRange');
exports.numberInRange = numberInRange;


/***/ }),
/* 33 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.bedroomSituationType = exports.bedroomSituations = void 0;
const tools_1 = __webpack_require__(23);
exports.bedroomSituations = [
    'own',
    'sister',
    'brother',
    'several',
    'various',
];
exports.bedroomSituationType = (0, tools_1.literalStringArrayTyping)('BedroomSituation', [
    ...exports.bedroomSituations,
]);


/***/ }),
/* 34 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.bookReadByType = exports.bookReadBys = void 0;
const tools_1 = __webpack_require__(23);
exports.bookReadBys = ['readTo', 'self', 'half'];
exports.bookReadByType = (0, tools_1.literalStringArrayTyping)('BookReadBy', exports.bookReadBys);


/***/ }),
/* 35 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Book = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
const childhood_age_1 = __webpack_require__(22);
const book_read_by_1 = __webpack_require__(34);
exports.Book = t.exact(t.type({
    title: t.string,
    author: t.string,
    character1: t.string,
    character2: t.string,
    synopsis: t.string,
    whyFavorite: t.string,
    howItInfluenced: t.string,
    ageWhenRead: childhood_age_1.childhoodAgeType.literals,
    readBy: book_read_by_1.bookReadByType.literals,
}));


/***/ }),
/* 36 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ChildhoodProfile = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
const sibling_position_1 = __webpack_require__(37);
const sibling_states_1 = __webpack_require__(38);
const gender_1 = __webpack_require__(39);
const parental_situation_1 = __webpack_require__(40);
const bedroom_situation_1 = __webpack_require__(33);
const dwelling_situation_1 = __webpack_require__(41);
const home_moves_1 = __webpack_require__(42);
const tools_1 = __webpack_require__(23);
const io_ts_types_1 = __webpack_require__(43);
exports.ChildhoodProfile = t.exact(t.type({
    id: io_ts_types_1.UUID,
    birthYear: (0, tools_1.numberInRange)(1900, new Date().getFullYear() - 10),
    gender: gender_1.genderType.literals,
    parents: parental_situation_1.parentalSituationType.literals,
    siblings: sibling_states_1.siblingStateType.literals,
    siblingPosition: sibling_position_1.siblingPositionType.literals,
    bedroomSituation: bedroom_situation_1.bedroomSituationType.literals,
    dwellingSituation: dwelling_situation_1.dwellingSituationType.literals,
    moves: home_moves_1.homeMovesType.literals,
    hobby: t.union([t.string, t.null]),
    favoriteColor: t.union([t.string, t.null]),
}), 'ChildhoodProfile');


/***/ }),
/* 37 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.siblingPositionType = exports.siblingPositions = void 0;
const tools_1 = __webpack_require__(23);
exports.siblingPositions = ['only', 'eldest', 'middle', 'youngest'];
exports.siblingPositionType = (0, tools_1.literalStringArrayTyping)('SiblingPosition', [...exports.siblingPositions]);


/***/ }),
/* 38 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.siblingStateType = exports.siblings = void 0;
const tools_1 = __webpack_require__(23);
exports.siblings = ['none', 'one', 'two', 'three', 'four', 'five', 'more'];
exports.siblingStateType = (0, tools_1.literalStringArrayTyping)('SiblingState', [...exports.siblings]);


/***/ }),
/* 39 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.genderType = exports.genders = void 0;
const tools_1 = __webpack_require__(23);
exports.genders = ['male', 'female'];
exports.genderType = (0, tools_1.literalStringArrayTyping)('Gender', [...exports.genders]);


/***/ }),
/* 40 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.parentalSituationType = exports.parentalSituations = void 0;
const tools_1 = __webpack_require__(23);
exports.parentalSituations = ['parents', 'father', 'mother', 'other'];
exports.parentalSituationType = (0, tools_1.literalStringArrayTyping)('ParentalSituation', [
    ...exports.parentalSituations,
]);


/***/ }),
/* 41 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.dwellingSituationType = exports.dwellingSituations = void 0;
const tools_1 = __webpack_require__(23);
exports.dwellingSituations = ['city', 'town', 'suburb', 'small_town', 'country', 'village', 'other'];
exports.dwellingSituationType = (0, tools_1.literalStringArrayTyping)('DwellingSituation', [
    ...exports.dwellingSituations,
]);


/***/ }),
/* 42 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.homeMovesType = void 0;
const tools_1 = __webpack_require__(23);
const homeMoves = ['0', '1', '2', '2+'];
exports.homeMovesType = (0, tools_1.literalStringArrayTyping)('HomeMoves', [...homeMoves]);


/***/ }),
/* 43 */
/***/ ((module) => {

module.exports = require("io-ts-types");

/***/ }),
/* 44 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.stateIsEast = exports.germanStateType = exports.germanStates = void 0;
const tools_1 = __webpack_require__(23);
exports.germanStates = [
    'BB',
    'BE',
    'BW',
    'BY',
    'HB',
    'HE',
    'HH',
    'MV',
    'NI',
    'NW',
    'RP',
    'SH',
    'SL',
    'SN',
    'ST',
    'TH',
];
exports.germanStateType = (0, tools_1.literalStringArrayTyping)('GermanState', [...exports.germanStates]);
const stateIsEast = (s) => ['MV', 'BB', 'SN', 'ST', 'TH'].includes(s);
exports.stateIsEast = stateIsEast;


/***/ }),
/* 45 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Grandparents = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
exports.Grandparents = t.exact(t.type({
    who: t.string,
    didYouMeet: t.string,
    getOn: t.string,
    activity: t.string,
    smell: t.string,
    association: t.string,
    specialMemory: t.string,
}));


/***/ }),
/* 46 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Holiday = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
exports.Holiday = t.exact(t.type({ holidayActivities: t.string }));


/***/ }),
/* 47 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ItemToggleValue = exports.itemsType = exports.items = void 0;
const tools_1 = __webpack_require__(23);
exports.items = ['book', 'grandparents', 'holidays', 'memory', 'song', 'party', 'speaking_book'];
exports.itemsType = (0, tools_1.literalStringArrayTyping)('Item', [...exports.items]);
exports.ItemToggleValue = {
    book: 1,
    grandparents: 2,
    holidays: 4,
    memory: 8,
    party: 16,
    song: 32,
    speaking_book: 64,
};


/***/ }),
/* 48 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getItemStatus = exports.itemProps = void 0;
const tslib_1 = __webpack_require__(4);
const grandparents_1 = __webpack_require__(45);
const holiday_1 = __webpack_require__(46);
const memory_1 = __webpack_require__(49);
const book_1 = __webpack_require__(35);
const song_1 = __webpack_require__(50);
const audio_book_1 = __webpack_require__(21);
const party_1 = __webpack_require__(51);
const nullableTranslatable_1 = __webpack_require__(52);
const t = tslib_1.__importStar(__webpack_require__(16));
exports.itemProps = {
    book: (0, nullableTranslatable_1.NullableTranslatableC)(book_1.Book),
    grandparents: (0, nullableTranslatable_1.NullableTranslatableC)(grandparents_1.Grandparents),
    holidays: (0, nullableTranslatable_1.NullableTranslatableC)(holiday_1.Holiday),
    memory: (0, nullableTranslatable_1.NullableTranslatableC)(memory_1.Memory),
    party: (0, nullableTranslatable_1.NullableTranslatableC)(party_1.Party),
    song: (0, nullableTranslatable_1.NullableTranslatableC)(song_1.Song),
    speaking_book: (0, nullableTranslatable_1.NullableTranslatableC)(audio_book_1.AudioBook),
};
const ItemsC = t.type(exports.itemProps);
const getItemStatus = (i) => ({
    book: i.book != null,
    grandparents: i.grandparents != null,
    holidays: i.holidays != null,
    memory: i.memory != null,
    party: i.party != null,
    song: i.song != null,
    speaking_book: i.speaking_book != null,
});
exports.getItemStatus = getItemStatus;


/***/ }),
/* 49 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Memory = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
exports.Memory = t.exact(t.type({ diverse: t.string }));


/***/ }),
/* 50 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Song = exports.songProps = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
const childhood_age_1 = __webpack_require__(22);
exports.songProps = {
    title: t.string,
    artist: t.string,
    reason: t.string,
    text: t.string,
    melody: t.string,
    listeningSituation: t.string,
    ageWhenImportant: childhood_age_1.childhoodAgeType.literals,
};
exports.Song = t.exact(t.type(exports.songProps));


/***/ }),
/* 51 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Party = exports.partyProps = exports.partyLikeType = exports.partyLikes = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
const tools_1 = __webpack_require__(23);
exports.partyLikes = ['very', 'not', 'ok'];
exports.partyLikeType = (0, tools_1.literalStringArrayTyping)('partyLike', [...exports.partyLikes]);
exports.partyProps = {
    reason: t.string,
    food: t.string,
    likeParty: exports.partyLikeType.literals,
    favoriteFood: t.string,
    game: t.string,
    favoriteGame: t.string,
    worstGame: t.string,
    specialMemory: t.string,
};
exports.Party = t.exact(t.type(exports.partyProps));


/***/ }),
/* 52 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.NullableTranslatableC = exports.TranslatableC = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
const language_1 = __webpack_require__(53);
const TranslatableC = (codec) => t.record(language_1.languageType.literals, t.union([codec, t.null]));
exports.TranslatableC = TranslatableC;
const NullableTranslatableC = (codec) => t.union([t.null, t.record(language_1.languageType.literals, t.union([codec, t.null]))]);
exports.NullableTranslatableC = NullableTranslatableC;


/***/ }),
/* 53 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.languageType = exports.languages = void 0;
const tools_1 = __webpack_require__(23);
exports.languages = ['en', 'de'];
exports.languageType = (0, tools_1.literalStringArrayTyping)('Language', [...exports.languages]);


/***/ }),
/* 54 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MatchingItemsC = exports.MatchingItemsProps = exports.MatchingItemC = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
const nullableTranslatable_1 = __webpack_require__(52);
const book_1 = __webpack_require__(35);
const grandparents_1 = __webpack_require__(45);
const holiday_1 = __webpack_require__(46);
const memory_1 = __webpack_require__(49);
const party_1 = __webpack_require__(51);
const song_1 = __webpack_require__(50);
const audio_book_1 = __webpack_require__(21);
const MatchingItemC = (codec) => t.type({ pid: t.number, weight: t.number, item: (0, nullableTranslatable_1.TranslatableC)(codec) });
exports.MatchingItemC = MatchingItemC;
exports.MatchingItemsProps = {
    book: (0, exports.MatchingItemC)(book_1.Book),
    grandparents: (0, exports.MatchingItemC)(grandparents_1.Grandparents),
    holidays: (0, exports.MatchingItemC)(holiday_1.Holiday),
    memory: (0, exports.MatchingItemC)(memory_1.Memory),
    party: (0, exports.MatchingItemC)(party_1.Party),
    song: (0, exports.MatchingItemC)(song_1.Song),
    speaking_book: (0, exports.MatchingItemC)(audio_book_1.AudioBook),
};
exports.MatchingItemsC = t.type(exports.MatchingItemsProps);


/***/ }),
/* 55 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Person = exports.DonatedProfile = exports.CountyC = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
const childhood_profile_1 = __webpack_require__(36);
const german_state_1 = __webpack_require__(44);
const item_type_map_1 = __webpack_require__(48);
const nullableTranslatable_1 = __webpack_require__(52);
exports.CountyC = t.keyof({
    'DE': 'Germany',
    'EN': 'England',
    'LT': 'Lithuania'
});
exports.DonatedProfile = t.intersection([
    childhood_profile_1.ChildhoodProfile,
    t.exact(t.type({
        germanState: t.union([german_state_1.germanStateType.literals, t.null]),
        dwellingSituationComment: (0, nullableTranslatable_1.NullableTranslatableC)(t.string),
        country: exports.CountyC,
        ...item_type_map_1.itemProps,
    })),
], 'DonatedProfile');
exports.Person = exports.DonatedProfile;


/***/ }),
/* 56 */
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));


/***/ }),
/* 57 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(58), exports);
tslib_1.__exportStar(__webpack_require__(60), exports);
tslib_1.__exportStar(__webpack_require__(59), exports);


/***/ }),
/* 58 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DateOnlyInput = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
const ymd_1 = __webpack_require__(59);
const dateToMidday = (input) => new Date(input.getFullYear(), input.getMonth(), input.getDate(), 12, 0, 0);
const isStringOrNumber = (input) => ['string', 'number'].includes(typeof input);
exports.DateOnlyInput = new t.Type('DateFromStringOrDateObject', (input) => input instanceof Date ||
    (typeof input === 'string' && !isNaN(Date.parse(input))) ||
    (typeof input === 'number' && !isNaN(new Date(input).valueOf())), (input, context) => {
    if (input instanceof Date)
        return t.success(dateToMidday(input));
    return isStringOrNumber(input)
        ? t.success(dateToMidday(new Date(input)))
        : t.failure(input, context, 'Input must be a number, Date instance or valid string date.');
}, ymd_1.ymd);


/***/ }),
/* 59 */
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ymd = void 0;
const ymd = (v) => `${v.getFullYear()}-${String(v.getMonth() + 1).padStart(2, '0')}-${String(v.getMonth() + 1).padStart(2, '0')}`;
exports.ymd = ymd;


/***/ }),
/* 60 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.NumberInRange = exports.NumberFromStringOrNumber = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
const io_ts_types_1 = __webpack_require__(43);
exports.NumberFromStringOrNumber = new t.Type('NumberFromStringOrNumber', (v) => t.number.is(v) || io_ts_types_1.NumberFromString.is(v), (v, c) => (typeof v === 'number' ? t.number.validate(v, c) : io_ts_types_1.NumberFromString.validate(v, c)), t.identity);
const NumberInRange = (min, max) => t.refinement(exports.NumberFromStringOrNumber, (n) => n >= min && n <= max);
exports.NumberInRange = NumberInRange;


/***/ }),
/* 61 */
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.fMapping = void 0;
const fMapping = (name, col = name) => `'${name}', ${col}`;
exports.fMapping = fMapping;


/***/ }),
/* 62 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ChildhoodProfileTable = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
const model_1 = __webpack_require__(17);
const db_safe_string_1 = __webpack_require__(63);
const io_ts_types_1 = __webpack_require__(43);
const tools_1 = __webpack_require__(23);
exports.ChildhoodProfileTable = t.exact(t.type({
    id: io_ts_types_1.UUID,
    gender: model_1.genderType.fromNumber,
    birthYear: (0, tools_1.numberInRange)(1900, new Date().getFullYear() - 10),
    siblings: model_1.siblingStateType.fromNumber,
    siblingPosition: model_1.siblingPositionType.fromNumber,
    bedroomSituation: model_1.bedroomSituationType.fromNumber,
    dwellingSituation: model_1.dwellingSituationType.fromNumber,
    moves: model_1.homeMovesType.fromNumber,
    parents: model_1.parentalSituationType.fromNumber,
    favoriteColor: db_safe_string_1.DbSafeString,
    hobby: db_safe_string_1.DbSafeString,
}));


/***/ }),
/* 63 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DbSafeString = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
const mysql2_1 = __webpack_require__(64);
exports.DbSafeString = new t.Type('mysqlsafestring', t.string.is, t.string.validate, mysql2_1.escape);


/***/ }),
/* 64 */
/***/ ((module) => {

module.exports = require("mysql2");

/***/ }),
/* 65 */
/***/ ((module) => {

module.exports = require("fp-ts/Record");

/***/ }),
/* 66 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BookItemTable = exports.BookItem = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
const model_1 = __webpack_require__(17);
const person_item_table_1 = __webpack_require__(67);
exports.BookItem = t.exact(t.type({
    title: t.string,
    author: t.string,
    character1: t.string,
    character2: t.string,
    synopsis: t.string,
    whyFavorite: t.string,
    howItInfluenced: t.string,
    ageWhenRead: model_1.childhoodAgeType.fromNumber,
    readBy: model_1.bookReadByType.fromNumber,
}));
exports.BookItemTable = t.intersection([person_item_table_1.PersonItemTable, exports.BookItem]);


/***/ }),
/* 67 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.PersonItemTable = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
exports.PersonItemTable = t.exact(t.type({
    id: t.number,
    pid: t.number,
}));


/***/ }),
/* 68 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SongTable = exports.SongItem = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
const model_1 = __webpack_require__(17);
const person_item_table_1 = __webpack_require__(67);
exports.SongItem = t.exact(t.type({ ...model_1.songProps, ageWhenImportant: model_1.childhoodAgeType.fromNumber }));
exports.SongTable = t.intersection([person_item_table_1.PersonItemTable, exports.SongItem]);


/***/ }),
/* 69 */
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.weights = void 0;
exports.weights = {
    birthYear: 5,
    bedroomSituation: 1,
    dwellingSituation: 1,
    parents: 1,
    siblingPosition: 1,
    siblings: 1,
    moves: 1,
    favoriteColor: 0,
    hobby: 0,
    gender: 8,
};


/***/ }),
/* 70 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.itemQueryTable = void 0;
const item_join_query_1 = __webpack_require__(71);
const book_item_1 = __webpack_require__(66);
const song_item_1 = __webpack_require__(68);
const model_1 = __webpack_require__(17);
const party_item_1 = __webpack_require__(73);
const audio_book_item_1 = __webpack_require__(74);
exports.itemQueryTable = {
    speaking_book: (0, item_join_query_1.itemJoinQuery)('speaking_book', audio_book_item_1.AudioBookItem.type),
    book: (0, item_join_query_1.itemJoinQuery)('book', book_item_1.BookItem.type),
    grandparents: (0, item_join_query_1.itemJoinQuery)('grandparents', model_1.Grandparents.type),
    holidays: (0, item_join_query_1.itemJoinQuery)('holidays', model_1.Holiday.type),
    memory: (0, item_join_query_1.itemJoinQuery)('memory', model_1.Memory.type),
    song: (0, item_join_query_1.itemJoinQuery)('song', song_item_1.SongItem.type),
    party: (0, item_join_query_1.itemJoinQuery)('party', party_item_1.PartyItem.type),
};


/***/ }),
/* 71 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.itemJoinQuery = void 0;
const tslib_1 = __webpack_require__(4);
const model_1 = __webpack_require__(17);
const function_1 = __webpack_require__(10);
const ReadonlyRecord_1 = __webpack_require__(72);
const A = tslib_1.__importStar(__webpack_require__(11));
const field_mapping_1 = __webpack_require__(61);
const itemJoinQuery = (i, type) => `json_object(${model_1.languages
    .map((l) => {
    return `'${l}', (CASE WHEN ${l}_${i}.id IS NULL THEN NULL ElSE  json_object(${(0, function_1.pipe)(type.props, ReadonlyRecord_1.keys, A.map((k) => (0, field_mapping_1.fMapping)(k, `${l}_${i}.${k}`))).join(',')}) END)`;
})
    .join(',')})`;
exports.itemJoinQuery = itemJoinQuery;


/***/ }),
/* 72 */
/***/ ((module) => {

module.exports = require("fp-ts/ReadonlyRecord");

/***/ }),
/* 73 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.PartyItem = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
const model_1 = __webpack_require__(17);
exports.PartyItem = t.exact(t.type({ ...model_1.partyProps, likeParty: model_1.partyLikeType.fromNumber }));


/***/ }),
/* 74 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AudioBookItem = void 0;
const io_ts_1 = __webpack_require__(16);
const model_1 = __webpack_require__(17);
exports.AudioBookItem = (0, io_ts_1.exact)((0, io_ts_1.type)({ ...model_1.audioBookProps, ageWhenImportant: model_1.childhoodAgeType.fromNumber }));


/***/ }),
/* 75 */
/***/ ((module) => {

module.exports = require("rxjs");

/***/ }),
/* 76 */
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.dbConfig = void 0;
exports.dbConfig = {
    host: 'wp095.webpack.hosteurope.de',
    user: 'dbu1060582',
    password: '6aT3nB8Nkdb',
    database: 'db1060582-becominggerman2',
    connectionLimit: 10,
    dateStrings: true,
};


/***/ }),
/* 77 */
/***/ ((module) => {

module.exports = require("io-ts/PathReporter");

/***/ }),
/* 78 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MemoryTable = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(16));
const person_item_table_1 = __webpack_require__(67);
const db_safe_string_1 = __webpack_require__(63);
exports.MemoryTable = t.intersection([person_item_table_1.PersonItemTable, t.type({ diverse: db_safe_string_1.DbSafeString })]);


/***/ }),
/* 79 */
/***/ ((module) => {

module.exports = require("express");

/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
var exports = __webpack_exports__;

Object.defineProperty(exports, "__esModule", ({ value: true }));
const common_1 = __webpack_require__(1);
const core_1 = __webpack_require__(2);
const app_module_1 = __webpack_require__(3);
async function bootstrap() {
    const app = await core_1.NestFactory.create(app_module_1.AppModule);
    const globalPrefix = 'api';
    app.setGlobalPrefix(globalPrefix);
    const port = process.env.PORT || 3000;
    await app.listen(port);
    common_1.Logger.log(`🚀 Application is running on: http://localhost:${port}/${globalPrefix}`);
}
bootstrap();

})();

var __webpack_export_target__ = exports;
for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ })()
;
//# sourceMappingURL=main.js.map