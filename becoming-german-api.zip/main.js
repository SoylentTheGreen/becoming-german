/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ([
/* 0 */,
/* 1 */
/***/ ((module) => {

module.exports = require("@nestjs/common");

/***/ }),
/* 2 */
/***/ ((module) => {

module.exports = require("@nestjs/core");

/***/ }),
/* 3 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AppModule = void 0;
const tslib_1 = __webpack_require__(4);
const common_1 = __webpack_require__(1);
const app_controller_1 = __webpack_require__(5);
const api_lib_1 = __webpack_require__(6);
__webpack_require__(68);
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = tslib_1.__decorate([
    (0, common_1.Module)({
        imports: [],
        controllers: [app_controller_1.AppController],
        providers: [{ provide: api_lib_1.PersonService, useClass: api_lib_1.PersonService }],
    })
], AppModule);


/***/ }),
/* 4 */
/***/ ((module) => {

module.exports = require("tslib");

/***/ }),
/* 5 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AppController = void 0;
const tslib_1 = __webpack_require__(4);
const common_1 = __webpack_require__(1);
const api_lib_1 = __webpack_require__(6);
const t = tslib_1.__importStar(__webpack_require__(21));
const function_1 = __webpack_require__(15);
const E = tslib_1.__importStar(__webpack_require__(17));
const Either_1 = __webpack_require__(17);
const model_1 = __webpack_require__(22);
const rxjs_1 = __webpack_require__(93);
const express_1 = __webpack_require__(96);
const tools_1 = __webpack_require__(28);
const TE = tslib_1.__importStar(__webpack_require__(12));
const getReqC = t.type({
    offset: tools_1.NumberFromStringOrNumber,
    limit: (0, tools_1.numberInRange)(1, 500),
});
const decodeOrDefault = (c, def) => (0, function_1.flow)(c.decode, (0, Either_1.fold)(() => def, (v) => v));
const defaultParams = { offset: 0, limit: 10 };
const getParamParser = decodeOrDefault(getReqC, defaultParams);
let AppController = class AppController {
    constructor(service) {
        this.service = service;
        this.results = new rxjs_1.Subject();
        this.repo = api_lib_1.MyRepo.getRepository();
    }
    hello() {
        return 'hello world!';
    }
    async getData(params) {
        const { offset, limit } = getParamParser({ ...defaultParams, ...params });
        return this.service.getData(offset, limit);
    }
    async createProfile(request) {
        const result = await (0, function_1.pipe)(model_1.ChildhoodAggregate.newState, model_1.ChildhoodAggregate.create(request), (r) => r[0], TE.fromOption(() => new common_1.HttpException('Invalid request payload', 400)), TE.chain(this.repo.save), TE.mapLeft((e) => new common_1.HttpException(e.message, 500)))();
        if (E.isLeft(result))
            throw result.left;
        return result.right;
    }
    async addItem(request, params) {
        const id = params.id;
        const rows = await (0, function_1.pipe)(this.repo.findByAggregateId(params.id), TE.map((rows) => (0, function_1.pipe)(E.left({ version: 0, state: null }), model_1.ChildhoodAggregate.build(rows))), TE.chain((result) => (0, function_1.pipe)(result[1], E.toUnion, (state) => (0, function_1.pipe)(Object.assign({}, request, { id }), model_1.ChildhoodAggregate.addItem(state.version + 1))(result[1]), (secondResult) => secondResult[0], TE.fromOption(() => new Error('no valid events')), TE.chain(this.repo.save))))();
        return E.isLeft(rows) ? new common_1.HttpException(rows.left.message, 500) : rows.right;
    }
    async getChildhood(params) {
        const result = await (0, function_1.pipe)(this.repo.findByAggregateId(params.id), TE.map(data => (0, function_1.pipe)(model_1.ChildhoodAggregate.build(data)(model_1.ChildhoodAggregate.newState), r => r[1], E.toUnion)))();
        if (E.isLeft(result))
            throw result.left;
        return result.right;
    }
    async getChildhoodRequest(request) {
        const res = await (0, function_1.pipe)(request, model_1.MatchingProfileRequestC.decode, E.chain(api_lib_1.ChildhoodProfileRequestTableC.decode), E.mapLeft(() => new common_1.HttpException('Failed to parse request', 400)), TE.fromEither, TE.chain((profile) => this.service.findMatchingItem(profile)), TE.toUnion)();
        console.log(res);
        return res;
    }
    migrate(response) {
        const gen = this.service.normalise(0, 100);
        response.setHeader('Content-Type', 'application/json');
        const createFrom = (asyncCollection) => {
            return new rxjs_1.Observable((subscriber) => {
                (async () => {
                    try {
                        for await (const value of asyncCollection()) {
                            subscriber.next(value);
                            // if(value[value.length-1].id > 100) break;<
                        }
                        subscriber.complete();
                        console.log('subscription completed');
                    }
                    catch (err) {
                        subscriber.error(err);
                    }
                })();
            });
        };
        createFrom(gen).subscribe({
            next: (rows) => response.write(JSON.stringify(rows)),
            complete: () => {
                console.log('complete has been called on migration');
                response.end();
            },
            error: (e) => {
                console.error(e);
                response.end();
            },
        });
    }
};
exports.AppController = AppController;
tslib_1.__decorate([
    (0, common_1.Get)('hello'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", []),
    tslib_1.__metadata("design:returntype", void 0)
], AppController.prototype, "hello", null);
tslib_1.__decorate([
    (0, common_1.Get)('admin/profiles/:offset?/:limit?'),
    tslib_1.__param(0, (0, common_1.Param)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [typeof (_b = typeof GetRec !== "undefined" && GetRec) === "function" ? _b : Object]),
    tslib_1.__metadata("design:returntype", Promise)
], AppController.prototype, "getData", null);
tslib_1.__decorate([
    (0, common_1.Post)('donate'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], AppController.prototype, "createProfile", null);
tslib_1.__decorate([
    (0, common_1.Post)('/:id/addItem'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__param(1, (0, common_1.Param)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, Object]),
    tslib_1.__metadata("design:returntype", Promise)
], AppController.prototype, "addItem", null);
tslib_1.__decorate([
    (0, common_1.Get)('/read/:id'),
    tslib_1.__param(0, (0, common_1.Param)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], AppController.prototype, "getChildhood", null);
tslib_1.__decorate([
    (0, common_1.Post)('request'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], AppController.prototype, "getChildhoodRequest", null);
tslib_1.__decorate([
    (0, common_1.Get)('admin/migrate'),
    tslib_1.__param(0, (0, common_1.Res)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [typeof (_c = typeof express_1.Response !== "undefined" && express_1.Response) === "function" ? _c : Object]),
    tslib_1.__metadata("design:returntype", void 0)
], AppController.prototype, "migrate", null);
exports.AppController = AppController = tslib_1.__decorate([
    (0, common_1.Controller)(),
    tslib_1.__metadata("design:paramtypes", [typeof (_a = typeof api_lib_1.PersonService !== "undefined" && api_lib_1.PersonService) === "function" ? _a : Object])
], AppController);


/***/ }),
/* 6 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(7), exports);


/***/ }),
/* 7 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(8), exports);
tslib_1.__exportStar(__webpack_require__(14), exports);
tslib_1.__exportStar(__webpack_require__(81), exports);
tslib_1.__exportStar(__webpack_require__(20), exports);
tslib_1.__exportStar(__webpack_require__(80), exports);
tslib_1.__exportStar(__webpack_require__(87), exports);
tslib_1.__exportStar(__webpack_require__(91), exports);
tslib_1.__exportStar(__webpack_require__(90), exports);
tslib_1.__exportStar(__webpack_require__(84), exports);
tslib_1.__exportStar(__webpack_require__(95), exports);
tslib_1.__exportStar(__webpack_require__(86), exports);
tslib_1.__exportStar(__webpack_require__(89), exports);
tslib_1.__exportStar(__webpack_require__(82), exports);


/***/ }),
/* 8 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MyRepo = void 0;
const tslib_1 = __webpack_require__(4);
exports.MyRepo = tslib_1.__importStar(__webpack_require__(9));


/***/ }),
/* 9 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getRepository = void 0;
const tslib_1 = __webpack_require__(4);
const promise_1 = __webpack_require__(10);
const Record_1 = __webpack_require__(11);
const TE = tslib_1.__importStar(__webpack_require__(12));
const config_1 = __webpack_require__(13);
const getRepository = (config = config_1.dbConfig) => new MysqlAggregateRepository((0, promise_1.createPool)(config));
exports.getRepository = getRepository;
const TryCatch = (cb) => TE.tryCatch(cb, (error) => (error instanceof Error ? error : new Error(`Unexpected error: ${error}`)));
class MysqlAggregateRepository {
    constructor(pool) {
        this.pool = pool;
        //
        this.findByAggregateId = (id) => TryCatch(() => this._findByAggregateId(id));
        this.save = (event) => TryCatch(() => this._save(event));
    }
    async q(sql, ...args) {
        const conn = await this.pool.getConnection();
        const res = await conn.execute(sql, args);
        conn.release();
        return res;
    }
    //
    // private async _aggregateExists(id: string): Promise<boolean> {
    //   const res = await this.q(`SELECT EXISTS( SELECT 1 FROM event_store WHERE aggregateId = ? ) AS 'exists'; `, id);
    //   return res[0]['exists'] === 1;
    // }
    //
    // aggregateExists = (id: string) => TryCatch(() => this._aggregateExists(id));
    //
    async _findByAggregateId(id) {
        const result = await this.q(`SELECT json_object(
      'id', id, 
      'type', type, 
      'aggregateId', aggregateId, 
      'aggregateType', aggregateType, 
      'aggregateVersion', aggregateVersion, 
      'timestamp', timestamp, 
      'payload', payload) as event from event_store WHERE aggregateId = ? ORDER BY aggregateVersion`, id);
        if (result[0] && Array.isArray(result[0]) && result[0].length)
            return result[0].map((row) => ({ ...row['event'], payload: JSON.parse(row['event']['payload']) }));
        throw new Error('no results found');
    }
    //
    // private _findWithSnapshot<T>(
    //   id: string,
    //   type: IOSType<AggregateSnapshotWithEvents<T>, unknown>,
    // ): TE.TaskEither<Error, AggregateSnapshotWithEvents<T>> {
    //   const sql = `SELECT JSON_OBJECT(
    //              'snapshot', COALESCE(snap.data, null),
    //              'events', COALESCE(es_events.events, JSON_ARRAY()))
    //          AS snapshot
    //     FROM (SELECT aggregateId,
    //            aggregateType,
    //            JSON_ARRAYAGG(
    //                    JSON_OBJECT(
    //                            'id', event_store.id,
    //                            'type', event_store.type,
    //                            'aggregateId', event_store.aggregateId,
    //                            'aggregateType', event_store.aggregateType,
    //                            'aggregateVersion', event_store.aggregateVersion,
    //                            'timestamp', event_store.timestamp,
    //                            'payload', event_store.payload
    //                        )
    //                ) AS events
    //     FROM event_store
    //     WHERE aggregateId = ?
    //       AND aggregateType = ?
    //     GROUP BY event_store.aggregateId, event_store.aggregateType) AS es_events
    //        LEFT JOIN event_store_snapshot snap
    //                  ON es_events.aggregateId = snap.aggregateId
    //                      AND es_events.aggregateType = snap.aggregateType;`;
    //   return pipe(
    //     TryCatch(() => this.q(sql, id, type)),
    //     TE.chain(([row]) => (row ? TE.right(row) : TE.left(new Error('no result found')))),
    //     TE.chain((row) =>
    //       pipe(
    //         row,
    //         type.decode,
    //         E.mapLeft(() => new Error(`could not decode ${row}`)),
    //         TE.fromEither,
    //       ),
    //     ),
    //   );
    // }
    //
    // findWithSnapshot<T>(
    //   id: string,
    //   type: IOSType<AggregateSnapshotWithEvents<T>, unknown>,
    // ): TE.TaskEither<Error, AggregateSnapshotWithEvents<T>> {
    //   return this._findWithSnapshot(id, type);
    // }
    //
    // private async _nextAggregateVersion(id: string, type: string): Promise<number> {
    //   const rows = await this.q(
    //     `
    //       SELECT
    //           COALESCE(MAX(aggregateVersion), 0) AS maxVersion
    //       FROM
    //           event_store
    //       WHERE
    //           aggregateId = ? AND aggregateType = ?;
    //   `,
    //     id,
    //     type,
    //   );
    //   return rows[0]['maxVersion'];
    // }
    //
    // nextAggregateVersion = (id: string, type: string): TE.TaskEither<Error, number> =>
    //   TryCatch(() => this._nextAggregateVersion(id, type));
    //
    async _save(event) {
        const asEntries = (0, Record_1.toEntries)({ ...event, payload: JSON.stringify(event.payload) });
        const res = await this.q(`
    INSERT INTO event_store ( ${asEntries.map(([k]) => k).join(',')} )
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE
    aggregateVersion = VALUES(aggregateVersion)`, ...asEntries.map(([, v]) => v));
        if (res[0]['affectedRows'] !== 1)
            throw new Error(`DB returned error: ${JSON.stringify(res[0])}`);
        return event;
    }
}


/***/ }),
/* 10 */
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),
/* 11 */
/***/ ((module) => {

module.exports = require("fp-ts/Record");

/***/ }),
/* 12 */
/***/ ((module) => {

module.exports = require("fp-ts/TaskEither");

/***/ }),
/* 13 */
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.dbConfig = void 0;
exports.dbConfig = {
    host: 'wp095.webpack.hosteurope.de',
    user: 'dbu1060582',
    password: '6aT3nB8Nkdb',
    database: 'db1060582-becominggerman2',
    connectionLimit: 10,
    dateStrings: true,
};


/***/ }),
/* 14 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MatchingItemsDBC = exports.PersonService = void 0;
const tslib_1 = __webpack_require__(4);
const promise_1 = __webpack_require__(10);
const function_1 = __webpack_require__(15);
const A = tslib_1.__importStar(__webpack_require__(16));
const Array_1 = __webpack_require__(16);
const E = tslib_1.__importStar(__webpack_require__(17));
const Either_1 = __webpack_require__(17);
const O = tslib_1.__importStar(__webpack_require__(18));
const TE = tslib_1.__importStar(__webpack_require__(12));
const io_ts_reporters_1 = __webpack_require__(19);
const person_table_1 = __webpack_require__(20);
const model_1 = __webpack_require__(22);
const rxjs_1 = __webpack_require__(93);
const book_item_1 = __webpack_require__(84);
const song_item_1 = __webpack_require__(86);
const audio_book_item_1 = __webpack_require__(88);
const party_item_1 = __webpack_require__(85);
const t = tslib_1.__importStar(__webpack_require__(21));
const config_1 = __webpack_require__(13);
const PathReporter_1 = __webpack_require__(94);
const processPerson = (row) => {
    return (0, function_1.pipe)(row['json_mapping'], person_table_1.PersonTable.decode, E.map(v => {
        console.log('we made it this far', v);
        return v;
    }), E.chain(model_1.ChildhoodC.decode), E.mapLeft(() => row['id']));
};
const processNormalizedPerson = (row) => {
    const validationResult = model_1.ChildhoodC.decode(row.jsonData);
    if ((0, Either_1.isLeft)(validationResult)) {
        console.log('failed decoding', PathReporter_1.PathReporter.report(validationResult));
    }
    return (0, function_1.pipe)(validationResult, (0, Either_1.mapLeft)(() => row.id));
};
const itemBitSum = (pt) => model_1.items.reduce((r, i) => (pt.profile[i] != null ? r + model_1.ItemToggleValue[i] : r), 0);
const updateJsonWithPool = (pool) => (person) => {
    return (0, function_1.pipe)(TE.tryCatch(async () => {
        const items_de = itemBitSum(person);
        const sql = `update tbl_german_person SET jsonData = ?, items_de = ?, migrated = 1 WHERE id = ?`;
        const conn = await pool.getConnection();
        await conn.execute(sql, [JSON.stringify(person), items_de, person.id]);
        conn.release();
        return { id: person.legacyId };
    }, (error) => ({ error, id: person.legacyId })));
};
class PersonService {
    constructor() {
        this.pool = (0, promise_1.createPool)(config_1.dbConfig);
        this.totalRows = new rxjs_1.BehaviorSubject(0);
    }
    async addQuarantined(ids) {
        const conn = await this.pool.getConnection();
        const sql = conn.format(`UPDATE tbl_german_person SET isQuarantined=1 WHERE id in (?)`, [ids]);
        console.log(sql);
        const [upResult] = await conn.execute(sql);
        console.warn(upResult['changedRows'], 'entries in german_person quarantined', ids);
    }
    async getNormalizedData(offset, limit) {
        const conn = await this.pool.getConnection();
        try {
            if (this.totalRows.getValue() === 0)
                this.totalRows.next((await conn.execute(person_table_1.countPersonSql))[0][0]['total']);
            const sql = (0, person_table_1.getNormalizePersonSql)(offset, limit);
            console.log(sql);
            const res = (0, function_1.pipe)(await conn.execute(sql), (r) => r[0], A.partitionMap(processNormalizedPerson));
            conn.release();
            return {
                status: 'ok',
                total: this.totalRows.getValue(),
                errors: res.left.length,
                offset,
                endId: res.right.length > 0 ? res.right[res.right.length - 1].id : offset,
                result: res.right,
            };
        }
        catch (e) {
            console.error(e);
            return { total: this.totalRows.getValue(), errors: 0, offset, endId: offset, result: [], status: 'error' };
        }
    }
    async getData(offset, limit) {
        const conn = await this.pool.getConnection();
        try {
            if (this.totalRows.getValue() === 0)
                this.totalRows.next((await conn.execute(person_table_1.countPersonSql))[0][0]['total']);
            const sql = (0, person_table_1.getPersonSql)(offset, limit);
            const res = (0, function_1.pipe)(await conn.execute(sql), (r) => r[0], A.partitionMap(processPerson));
            if (res.left.length > 0)
                await this.addQuarantined(res.left);
            conn.release();
            return {
                status: 'ok',
                total: this.totalRows.getValue(),
                errors: res.left.length,
                offset,
                endId: res.right.length > 0 ? res.right[res.right.length - 1].id : offset,
                result: res.right,
            };
        }
        catch (e) {
            console.error(e);
            return { total: this.totalRows.getValue(), errors: 0, offset, endId: offset, result: [], status: 'error' };
        }
    }
    normalise(fromId, limit = 500) {
        const update = updateJsonWithPool(this.pool);
        const getData = (id) => TE.tryCatch(() => this.getData(id, limit), (error) => ({ error, id }));
        const queryToUpdate = (0, function_1.flow)((r) => r.result, A.map(update), A.map(TE.fold(TE.right, TE.right)), A.sequence(TE.ApplicativePar));
        const getRes = async function* (currentId = fromId) {
            const result = await (0, function_1.pipe)(getData(currentId), TE.chain(queryToUpdate))();
            if (E.isLeft(result)) {
                console.log('result is left', result.left);
                yield [];
            }
            else {
                const lastId = (0, Array_1.last)(result.right); // Assuming the last number in the array is the
                if (O.isNone(lastId)) {
                    console.log('last id is null');
                    yield [];
                    return;
                }
                if (lastId.value.error) {
                    console.log('we have an error on', lastId.value.id);
                    yield [];
                    return;
                }
                else {
                    yield result.right;
                    yield* getRes(lastId.value.id);
                }
            }
            return;
        };
        return getRes;
    }
    async _findMatchingItem(profile) {
        const exe = async (sql) => {
            const conn = await this.pool.getConnection();
            const [rows] = await conn.execute(sql);
            conn.release();
            return rows;
        };
        const results = (await Promise.all((0, person_table_1.getSearch)(profile).map(exe))).flat();
        return processMatchingItem(results);
    }
    findMatchingItem(profile) {
        return (0, function_1.pipe)(TE.tryCatch(() => this._findMatchingItem(profile), (e) => (e instanceof Error ? e : new Error(`${e}`))), TE.chain(TE.fromEither));
    }
}
exports.PersonService = PersonService;
exports.MatchingItemsDBC = t.type({
    book: (0, model_1.MatchingItemC)(book_item_1.BookItem),
    grandparents: (0, model_1.MatchingItemC)(model_1.Grandparents),
    holidays: (0, model_1.MatchingItemC)(model_1.Holiday),
    memory: (0, model_1.MatchingItemC)(t.string),
    party: (0, model_1.MatchingItemC)(party_item_1.PartyItem),
    song: (0, model_1.MatchingItemC)(song_item_1.SongItem),
    audioBook: (0, model_1.MatchingItemC)(audio_book_item_1.AudioBookItem),
});
const processMatchingItem = (rows) => {
    console.log(JSON.stringify(rows, undefined, 2));
    return (0, function_1.pipe)(rows, A.map((r) => r.jsonItem), A.reduce({}, (r, v) => ({ ...r, ...v })), exports.MatchingItemsDBC.decode, E.mapLeft(io_ts_reporters_1.formatValidationErrors), E.mapLeft((errors) => new Error(errors.join('\n'))));
};


/***/ }),
/* 15 */
/***/ ((module) => {

module.exports = require("fp-ts/function");

/***/ }),
/* 16 */
/***/ ((module) => {

module.exports = require("fp-ts/Array");

/***/ }),
/* 17 */
/***/ ((module) => {

module.exports = require("fp-ts/Either");

/***/ }),
/* 18 */
/***/ ((module) => {

module.exports = require("fp-ts/Option");

/***/ }),
/* 19 */
/***/ ((module) => {

module.exports = require("io-ts-reporters");

/***/ }),
/* 20 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getSearch = exports.getPersonSql = exports.getNormalizePersonSql = exports.countPersonSql = exports.PersonTable = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const model_1 = __webpack_require__(22);
const field_mapping_1 = __webpack_require__(80);
const childhood_profile_table_1 = __webpack_require__(81);
const function_1 = __webpack_require__(15);
const Record_1 = __webpack_require__(11);
const A = tslib_1.__importStar(__webpack_require__(16));
const weights_1 = __webpack_require__(89);
const item_query_table_1 = __webpack_require__(90);
const io_ts_types_1 = __webpack_require__(40);
exports.PersonTable = t.type({
    id: io_ts_types_1.UUID,
    legacyId: t.number,
    situation: model_1.ChildhoodSituationC,
    profile: t.type({
        de: childhood_profile_table_1.ChildhoodProfileTable,
        en: childhood_profile_table_1.ChildhoodProfileTable,
    }),
});
const personTableMappingConfig = [
    ['bedroomSituation'],
    ['birthDate'],
    ['dwellingSituation'],
    ['parents'],
    ['gender', 'sex'],
    ['germanState'],
    ['moves', 'homeMoves'],
    ['siblingPosition'],
    ['siblings'],
];
const personTableMapping = personTableMappingConfig.map(([a, b]) => (0, field_mapping_1.fMapping)(a, `${b || a}`));
exports.countPersonSql = `SELECT count(*) as total from tbl_german_person WHERE isQuarantined=0`;
const getNormalizePersonSql = (offset = 0, limit = 10) => {
    return `select id, jsonData from tbl_german_person where id > ${offset} AND isQuarantined = false limit ${limit}`;
};
exports.getNormalizePersonSql = getNormalizePersonSql;
const itemToTbl = (i) => (i === 'audioBook' ? 'speaking_book' : i);
const getPersonSql = (offset = 0, limit = 10) => {
    const items = (lang = '') => (0, function_1.pipe)(item_query_table_1.itemQueryTable, Record_1.toEntries, A.map(([k, v]) => `'${k}', (SELECT ${v} 
        FROM ${lang}tbl_${itemToTbl(k)}  
        WHERE pid=p.id LIMIT 1)`), A.concat(['favoriteColor', 'hobby', 'hatedFood', 'softToy', 'dwellingSituationComment'].flatMap(a => [`'${a}'`, lang == '' ? a : `''`]))).join(',');
    return `
  SELECT id, json_object('situation', json_object(
  ${personTableMapping.join(', ')}), 'profile', json_object('de', json_object(${items('')}), 'en', json_object(${items('eng_')})), 'id', uuid, 'legacyId', id) as json_mapping
  FROM tbl_german_person p
  WHERE 
    isQuarantined=0
    AND p.id > ${offset}
  ORDER BY p.id  
  LIMIT ${limit}`;
};
exports.getPersonSql = getPersonSql;
const fieldName = (k) => k === 'gender' ? 'sex' : k === 'moves' ? 'homeMoves' : k;
const getSearch = (p) => {
    const data = childhood_profile_table_1.ChildhoodProfileRequestTableC.encode(p);
    const weightField = `
      IF(
      ABS(DATE_FORMAT(birthDate,"%Y")-${p.birthYear}) <= ${weights_1.weights.birthYear}, 
      ${weights_1.weights.birthYear} - ABS(DATE_FORMAT(birthDate,"%Y")-${p.birthYear}), 0)+
      ${Object.entries(weights_1.weights)
        .filter(([k]) => k !== 'birthYear')
        .map(([k, v]) => `if(${fieldName(k)}=${data[k]}, ${v}, 0)`)
        .join('+')}`;
    const divisor = Object.values(weights_1.weights).reduce((r, v) => r + v, 0);
    const getSql = (k) => `
  SELECT p.id, ${weightField} as weight,
   json_object('${k}', 
    json_object( 
    'weight', (${weightField}) / ${divisor} * 100,
    'pid', p.id,
    'item',${item_query_table_1.itemQueryTable[k]})) as jsonItem
  FROM tbl_german_person p inner join tbl_${itemToTbl(k)} i ON p.id = i.pid
  WHERE 
  items_de & ${model_1.ItemToggleValue[k]}
  AND  isQuarantined = 0
  ORDER BY weight DESC LIMIT 1`;
    const sql = model_1.items.map((i) => `(${getSql(i)})`);
    // const sql = [`(${getSql('book')})`]
    //   const sql = `
    //
    //   SELECT p.id, ${weightField} / ${divisor} * 100 as weight, json_object(
    //   'weight', ${weightField} / ${divisor} * 100,
    //   'memory', JSON_OBJECT('de', item.diverse, 'en', eItem.diverse)) as jsonItem
    // FROM tbl_german_person p
    //          JOIN (tbl_memory item LEFT JOIN eng_tbl_memory eItem ON item.id = eItem.id) ON p.id = item.pid
    // WHERE item.id is not null ORDER BY weight DESC LIMIT 1`;
    //   const sql =  pipe(
    //     itemTables,
    //     toEntries,
    //     A.map(
    //       ([item]) =>
    //         `
    //     (SELECT
    //
    //       JSON_OBJECT(
    //
    //       '${item}', (${getItemSql(item)})) as jsonResult
    //       FROM tbl_german_person, ${getItemTableName(item)} b
    //       WHERE b.pid = tbl_german_person.id
    //       AND ${weightField} > 0
    //       ORDER BY weight DESC
    //       limit 1)
    // `,
    //     ),
    //   ).join(' UNION ');
    console.log(sql[0]);
    return sql;
};
exports.getSearch = getSearch;
/*
const t = `
    (SELECT
      (${weightField}) / ${divisor} * 100 as weight,
      JSON_OBJECT(
      'weight',  (${weightField}) / ${divisor} * 100,
      '${item}', (${getItemSql(item)})) as jsonResult
      FROM tbl_german_person, ${getItemTableName(item)} b
      WHERE
      b.pid = tbl_german_person.id
      AND ${weightField} > 0
      ORDER BY weight DESC
      limit 1)
`
 */


/***/ }),
/* 21 */
/***/ ((module) => {

module.exports = require("io-ts");

/***/ }),
/* 22 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(23), exports);


/***/ }),
/* 23 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(24), exports);
tslib_1.__exportStar(__webpack_require__(25), exports);
tslib_1.__exportStar(__webpack_require__(61), exports);


/***/ }),
/* 24 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.decodeOrNull = void 0;
const tslib_1 = __webpack_require__(4);
const function_1 = __webpack_require__(15);
const E = tslib_1.__importStar(__webpack_require__(17));
const decodeOrNull = (codec) => (0, function_1.flow)(codec.decode, E.fold(() => null, (v) => v));
exports.decodeOrNull = decodeOrNull;


/***/ }),
/* 25 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ChildhoodAggregate = void 0;
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(26), exports);
tslib_1.__exportStar(__webpack_require__(43), exports);
tslib_1.__exportStar(__webpack_require__(44), exports);
tslib_1.__exportStar(__webpack_require__(45), exports);
tslib_1.__exportStar(__webpack_require__(46), exports);
exports.ChildhoodAggregate = tslib_1.__importStar(__webpack_require__(51));
tslib_1.__exportStar(__webpack_require__(27), exports);
tslib_1.__exportStar(__webpack_require__(53), exports);
tslib_1.__exportStar(__webpack_require__(58), exports);
tslib_1.__exportStar(__webpack_require__(72), exports);
tslib_1.__exportStar(__webpack_require__(56), exports);
tslib_1.__exportStar(__webpack_require__(60), exports);
tslib_1.__exportStar(__webpack_require__(47), exports);
tslib_1.__exportStar(__webpack_require__(48), exports);
tslib_1.__exportStar(__webpack_require__(59), exports);
tslib_1.__exportStar(__webpack_require__(69), exports);
tslib_1.__exportStar(__webpack_require__(75), exports);
tslib_1.__exportStar(__webpack_require__(67), exports);
tslib_1.__exportStar(__webpack_require__(76), exports);
tslib_1.__exportStar(__webpack_require__(57), exports);
tslib_1.__exportStar(__webpack_require__(49), exports);
tslib_1.__exportStar(__webpack_require__(65), exports);
tslib_1.__exportStar(__webpack_require__(77), exports);
tslib_1.__exportStar(__webpack_require__(54), exports);
tslib_1.__exportStar(__webpack_require__(55), exports);
tslib_1.__exportStar(__webpack_require__(50), exports);
tslib_1.__exportStar(__webpack_require__(66), exports);
tslib_1.__exportStar(__webpack_require__(78), exports);


/***/ }),
/* 26 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AudioBook = exports.audioBookProps = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const childhood_age_1 = __webpack_require__(27);
exports.audioBookProps = {
    title: t.string,
    author: t.string,
    themeMusic: t.string,
    synopsis: t.string,
    reason: t.string,
    listeningSituation: t.string,
    ageWhenImportant: childhood_age_1.childhoodAgeType.literals,
};
exports.AudioBook = t.type(exports.audioBookProps);


/***/ }),
/* 27 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.childhoodAgeType = exports.childhoodAges = void 0;
const tools_1 = __webpack_require__(28);
exports.childhoodAges = ['<5', '5-6', '7-8', '9-10', '10-11', '12-13', '>13'];
exports.childhoodAgeType = (0, tools_1.literalStringArrayTyping)('ChildhoodAge', [...exports.childhoodAges]);


/***/ }),
/* 28 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(29), exports);


/***/ }),
/* 29 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(30), exports);
tslib_1.__exportStar(__webpack_require__(32), exports);


/***/ }),
/* 30 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(31), exports);


/***/ }),
/* 31 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.fpFormGroup = exports.fpValidator = void 0;
const tslib_1 = __webpack_require__(4);
const function_1 = __webpack_require__(15);
const Record_1 = __webpack_require__(11);
const A = tslib_1.__importStar(__webpack_require__(16));
const E = tslib_1.__importStar(__webpack_require__(17));
const fpValidator = (c) => (0, function_1.flow)((ctl) => ctl.value, c.decode, E.fold(() => ({ invalid: true }), () => null));
exports.fpValidator = fpValidator;
const fpFormGroup = (props) => (0, function_1.pipe)(props, Record_1.toEntries, A.reduce({}, (r, [k, v]) => ({
    ...r,
    [k]: [null, [(0, exports.fpValidator)(v)]],
})));
exports.fpFormGroup = fpFormGroup;


/***/ }),
/* 32 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(33), exports);
tslib_1.__exportStar(__webpack_require__(34), exports);
tslib_1.__exportStar(__webpack_require__(36), exports);
tslib_1.__exportStar(__webpack_require__(38), exports);
tslib_1.__exportStar(__webpack_require__(39), exports);
tslib_1.__exportStar(__webpack_require__(41), exports);
tslib_1.__exportStar(__webpack_require__(42), exports);


/***/ }),
/* 33 */
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.constArrayValueToNumber = void 0;
const constArrayValueToNumber = (constArray) => (i) => constArray.indexOf(i);
exports.constArrayValueToNumber = constArrayValueToNumber;


/***/ }),
/* 34 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.isInConstArray = void 0;
const string_1 = __webpack_require__(35);
const isInConstArray = (constArray) => {
    return (a) => (0, string_1.isString)(a) && constArray.includes(a);
};
exports.isInConstArray = isInConstArray;


/***/ }),
/* 35 */
/***/ ((module) => {

module.exports = require("fp-ts/string");

/***/ }),
/* 36 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.literalStringArrayTyping = exports.ordFromLiterals = void 0;
const tslib_1 = __webpack_require__(4);
const index_1 = __webpack_require__(32);
const t = tslib_1.__importStar(__webpack_require__(21));
const Ord_1 = __webpack_require__(37);
const isNum = (i) => Number.isInteger(i);
const ordFromLiterals = (constArray) => (0, Ord_1.fromCompare)((a, b) => {
    const idxA = constArray.indexOf(a);
    const idxB = constArray.indexOf(b);
    if (idxA === idxB)
        return 0;
    return idxA > idxB ? 1 : -1;
});
exports.ordFromLiterals = ordFromLiterals;
const literalStringArrayTyping = (typeName, constArray) => {
    const literalArray = t.keyof(constArray.reduce((r, k) => ({ ...r, [k]: null }), {}));
    const fromNumber = new t.Type(`${typeName}FromNumber`, (inp) => literalArray.is(inp) || (isNum(inp) && inp > 0 && inp < constArray.length), (input, context) => {
        if (typeof input === 'string')
            return literalArray.validate(input, context);
        const r = isNum(input) ? (0, index_1.numTo1BasedConst)(constArray)(input) : null;
        return r === null ? t.failure(input, context, `invalid value for ${typeName}`) : t.success(r);
    }, (out) => constArray.indexOf(out) + 1);
    const literals = new t.Type(typeName, fromNumber.is, fromNumber.validate, t.identity);
    return {
        values: constArray,
        guard: (0, index_1.isInConstArray)(constArray),
        fromNumber,
        literals,
        ord: (0, exports.ordFromLiterals)(constArray),
    };
};
exports.literalStringArrayTyping = literalStringArrayTyping;


/***/ }),
/* 37 */
/***/ ((module) => {

module.exports = require("fp-ts/Ord");

/***/ }),
/* 38 */
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.numTo1BasedConst = void 0;
const numTo1BasedConst = (constArray) => (i) => (i < 1 || i > constArray.length) ? null : constArray[i - 1];
exports.numTo1BasedConst = numTo1BasedConst;


/***/ }),
/* 39 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.NumberFromStringOrNumber = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const io_ts_types_1 = __webpack_require__(40);
exports.NumberFromStringOrNumber = new t.Type('NumberFromStringOrNumber', (v) => t.number.is(v) || io_ts_types_1.NumberFromString.is(v), (v, c) => (typeof v === 'number' ? t.number.validate(v, c) : io_ts_types_1.NumberFromString.validate(v, c)), t.identity);


/***/ }),
/* 40 */
/***/ ((module) => {

module.exports = require("io-ts-types");

/***/ }),
/* 41 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.numberInRange = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const number_from_string_or_number_1 = __webpack_require__(39);
const numberInRange = (min, max) => t.refinement(number_from_string_or_number_1.NumberFromStringOrNumber, (n) => n >= min && n <= max, 'NumberInRange');
exports.numberInRange = numberInRange;


/***/ }),
/* 42 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UUID = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
exports.UUID = t.refinement(t.string, (u) => /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(u), 'UUID');


/***/ }),
/* 43 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.bedroomSituationType = exports.bedroomSituations = void 0;
const tools_1 = __webpack_require__(28);
exports.bedroomSituations = [
    'own',
    'sister',
    'brother',
    'several',
    'various',
];
exports.bedroomSituationType = (0, tools_1.literalStringArrayTyping)('BedroomSituation', [
    ...exports.bedroomSituations,
]);


/***/ }),
/* 44 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.bookReadByType = exports.bookReadBys = void 0;
const tools_1 = __webpack_require__(28);
exports.bookReadBys = ['readTo', 'self', 'half'];
exports.bookReadByType = (0, tools_1.literalStringArrayTyping)('BookReadBy', exports.bookReadBys);


/***/ }),
/* 45 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Book = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const childhood_age_1 = __webpack_require__(27);
const book_read_by_1 = __webpack_require__(44);
exports.Book = t.type({
    title: t.string,
    author: t.string,
    character1: t.string,
    character2: t.string,
    synopsis: t.string,
    whyFavorite: t.string,
    howItInfluenced: t.string,
    ageWhenRead: childhood_age_1.childhoodAgeType.literals,
    readBy: book_read_by_1.bookReadByType.literals,
});


/***/ }),
/* 46 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ChildhoodItems = void 0;
const book_1 = __webpack_require__(45);
const grandparents_1 = __webpack_require__(47);
const holiday_1 = __webpack_require__(48);
const party_1 = __webpack_require__(49);
const song_1 = __webpack_require__(50);
const audio_book_1 = __webpack_require__(26);
exports.ChildhoodItems = {
    book: book_1.Book,
    grandparents: grandparents_1.Grandparents,
    holidays: holiday_1.Holiday,
    party: party_1.Party,
    song: song_1.Song,
    audioBook: audio_book_1.AudioBook,
};


/***/ }),
/* 47 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Grandparents = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
exports.Grandparents = t.type({
    who: t.string,
    didYouMeet: t.string,
    getOn: t.string,
    activity: t.string,
    smell: t.string,
    association: t.string,
    specialMemory: t.string,
});


/***/ }),
/* 48 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Holiday = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
exports.Holiday = t.type({ holidayActivities: t.string });


/***/ }),
/* 49 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Party = exports.partyProps = exports.partyLikeType = exports.partyLikes = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const tools_1 = __webpack_require__(28);
exports.partyLikes = ['very', 'not', 'ok'];
exports.partyLikeType = (0, tools_1.literalStringArrayTyping)('partyLike', [...exports.partyLikes]);
exports.partyProps = {
    reason: t.string,
    food: t.string,
    likeParty: exports.partyLikeType.literals,
    favoriteFood: t.string,
    game: t.string,
    favoriteGame: t.string,
    worstGame: t.string,
    specialMemory: t.string,
};
exports.Party = t.type(exports.partyProps);


/***/ }),
/* 50 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Song = exports.songProps = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const childhood_age_1 = __webpack_require__(27);
exports.songProps = {
    title: t.string,
    artist: t.string,
    reason: t.string,
    text: t.string,
    melody: t.string,
    listeningSituation: t.string,
    ageWhenImportant: childhood_age_1.childhoodAgeType.literals,
};
exports.Song = t.type(exports.songProps);


/***/ }),
/* 51 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.begin = exports.newState = exports.fromEvents = exports.nextEvent = exports.build = exports.addItem = exports.create = exports.getStateMapper = exports.itemAddedPayloadC = void 0;
const tslib_1 = __webpack_require__(4);
const S = tslib_1.__importStar(__webpack_require__(52));
const t = tslib_1.__importStar(__webpack_require__(21));
const E = tslib_1.__importStar(__webpack_require__(17));
const R = tslib_1.__importStar(__webpack_require__(11));
const childhood_situation_1 = __webpack_require__(53);
const donated_profile_1 = __webpack_require__(65);
const function_1 = __webpack_require__(15);
const O = tslib_1.__importStar(__webpack_require__(18));
const uuid_1 = __webpack_require__(68);
const io_ts_types_1 = __webpack_require__(40);
const language_1 = __webpack_require__(67);
const immutable_1 = __webpack_require__(71);
//list of operations
/**
 * 1. MigrateProfile ProfileMigrated<Childhood<Country>>
 * 2. DonatedSituation <Childhood>
 * 3. AddItem <>
 *   //Here we have a valid Childhood
 * 5. SnapShotCreated
 * 4. UpdateSituation
 * 5. UpdateItem
 * 6. AddItemTranslation
 */
exports.itemAddedPayloadC = t.refinement(t.type({
    id: io_ts_types_1.UUID,
    type: t.keyof(donated_profile_1.childhoodProfileProps),
    language: language_1.languageType.literals,
    item: t.union([t.string, t.null, ...Object.values(donated_profile_1.childhoodProfileProps)]),
}), (v) => E.isRight(donated_profile_1.childhoodProfileProps[v.type].decode(v.item)), 'ItemAddedPayload');
const ChildhoodEvents = {
    'profile-migrated': donated_profile_1.DonatedProfileC,
    'profile-created': donated_profile_1.DonatedProfileC,
    'item-added': exports.itemAddedPayloadC,
    // 'snapshot-created': ChildhoodC,
    // 'situation-updated': ChildhoodSituationC,
    // 'item-updated': itemAddedC,
    // 'profile-translated': t.type({ language: languageType.literals, profile: ChildhoodProfileC }),
};
const ChildhoodEventC = (key, payload) => t.type({
    id: io_ts_types_1.UUID,
    type: t.literal(key),
    aggregateType: t.literal(donated_profile_1.ChildhoodC.name),
    aggregateId: io_ts_types_1.UUID,
    aggregateVersion: t.number,
    payload,
    timestamp: t.number,
});
const profileCreatedC = ChildhoodEventC('profile-created', donated_profile_1.DonatedProfileC);
const profileMigratedC = ChildhoodEventC('profile-migrated', t.type({ legacyId: t.number, state: donated_profile_1.ChildhoodC }));
const itemAddedC = ChildhoodEventC('item-added', exports.itemAddedPayloadC);
const makeEvent = (type, payload, aggregateId, aggregateVersion) => ({
    id: (0, uuid_1.v4)(),
    type,
    aggregateType: donated_profile_1.ChildhoodC.name,
    aggregateId: aggregateId,
    aggregateVersion,
    payload,
    timestamp: Date.now(),
});
const emptyProfile = (id, situation) => ({
    id,
    legacyId: null,
    situation,
    profile: { de: emptyChildhoodProfile, en: emptyChildhoodProfile },
});
const unchanged = () => (s) => [O.none, s];
const profileCreatedEventBuilder = (0, function_1.flow)(childhood_situation_1.ChildhoodSituationC.decode, E.map((p) => emptyProfile((0, uuid_1.v4)(), childhood_situation_1.ChildhoodSituationC.encode(p))), E.chain((0, function_1.flow)((payload) => makeEvent('profile-created', payload, payload.id, 1), profileCreatedC.decode)), O.fromEither);
const itemAddedEventBuilder = (previousVersion) => (payload) => (0, function_1.pipe)(payload, exports.itemAddedPayloadC.decode, E.chain((0, function_1.flow)((payload) => makeEvent('item-added', payload, payload.id, previousVersion), itemAddedC.decode)), O.fromEither);
const profileCreatedStateMapper = (event) => () => [O.some(event), E.left({ version: 1, state: event.payload })];
const profileMigratedStateMapper = (event) => () => [O.some(event), E.left({ version: 1, state: event.payload.state })];
const itemAddedStateMapper = (event) => (s) => {
    const arrgghhh = (0, function_1.pipe)(s, E.toUnion, (acc) => {
        if (acc.version + 1 !== event.aggregateVersion)
            return O.none;
        return O.some(acc);
    }, O.chain((acc) => (0, function_1.pipe)((0, immutable_1.fromJS)(acc.state).setIn(['profile', event.payload.language, event.payload.type], event.payload.item).toJS(), donated_profile_1.DonatedProfileC.decode, O.fromEither)));
    if (O.isNone(arrgghhh))
        return [O.none, s];
    const newV = (state) => ({ version: event.aggregateVersion, state });
    return [
        O.some(event),
        (0, function_1.pipe)(donated_profile_1.ChildhoodC.decode(arrgghhh.value), E.mapLeft(() => newV(arrgghhh.value)), E.map(newV)),
    ];
};
const emptyChildhoodProfile = {
    memory: null,
    book: null,
    grandparents: null,
    holidays: null,
    party: null,
    song: null,
    audioBook: null,
    hobby: null,
    favoriteColor: null,
    hatedFood: null,
    dwellingSituationComment: null,
    softToy: null,
};
const eventCodecs = {
    'profile-created': (0, function_1.flow)(profileCreatedC.decode, O.fromEither, O.map(profileCreatedStateMapper)),
    'profile-migrated': (0, function_1.flow)(profileMigratedC.decode, O.fromEither, O.map(profileMigratedStateMapper)),
    'item-added': (0, function_1.flow)(itemAddedC.decode, O.fromEither, O.map(itemAddedStateMapper)),
};
const getStateMapper = (event) => (0, function_1.pipe)(eventCodecs, R.lookup(event.type), O.chain((f) => f(event)), O.getOrElse(unchanged));
exports.getStateMapper = getStateMapper;
const create = (p) => (0, function_1.pipe)(p, profileCreatedEventBuilder, O.map(profileCreatedStateMapper), O.fold(unchanged, function_1.identity));
exports.create = create;
const addItem = (version) => (payload) => (0, function_1.pipe)(itemAddedEventBuilder(version)(payload), O.map(itemAddedStateMapper), O.fold(unchanged, function_1.identity));
exports.addItem = addItem;
const build = (events) => (0, function_1.pipe)(events.map(exports.getStateMapper), S.sequenceArray);
exports.build = build;
exports.nextEvent = (0, function_1.flow)(exports.getStateMapper);
const fromEvents = (events) => (0, function_1.pipe)(E.left({ version: 0, state: null }), (0, exports.build)(events), (r) => r[1]);
exports.fromEvents = fromEvents;
exports.newState = E.left({ version: 0, state: null });
exports.begin = S.of([O.none, exports.newState]);


/***/ }),
/* 52 */
/***/ ((module) => {

module.exports = require("fp-ts/State");

/***/ }),
/* 53 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MatchingProfileRequestC = exports.ChildhoodSituationC = exports.ChildhoodSituationProps = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const sibling_position_1 = __webpack_require__(54);
const sibling_states_1 = __webpack_require__(55);
const gender_1 = __webpack_require__(56);
const parental_situation_1 = __webpack_require__(57);
const bedroom_situation_1 = __webpack_require__(43);
const dwelling_situation_1 = __webpack_require__(58);
const home_moves_1 = __webpack_require__(59);
const german_state_1 = __webpack_require__(60);
const type_1 = __webpack_require__(61);
const tools_1 = __webpack_require__(28);
exports.ChildhoodSituationProps = {
    gender: gender_1.genderType.literals,
    parents: parental_situation_1.parentalSituationType.literals,
    siblings: sibling_states_1.siblingStateType.literals,
    siblingPosition: sibling_position_1.siblingPositionType.literals,
    bedroomSituation: bedroom_situation_1.bedroomSituationType.literals,
    dwellingSituation: dwelling_situation_1.dwellingSituationType.literals,
    moves: home_moves_1.homeMovesType.literals,
};
exports.ChildhoodSituationC = t.type({
    birthDate: t.refinement(type_1.DateOnlyInput, (d) => d.getFullYear() > 1900 && d.getFullYear() < new Date().getFullYear() - 10),
    germanState: german_state_1.germanStateType.literals,
    ...exports.ChildhoodSituationProps,
});
exports.MatchingProfileRequestC = t.type({
    ...exports.ChildhoodSituationProps,
    favoriteColor: t.string,
    hobby: t.string,
    birthYear: t.refinement(tools_1.NumberFromStringOrNumber, (n) => Number.isInteger(n) && n > 1900 && n < new Date().getFullYear() - 10),
    eastOnly: t.union([t.boolean, t.null]),
    westOnly: t.union([t.boolean, t.null]),
});


/***/ }),
/* 54 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.siblingPositionType = exports.siblingPositions = void 0;
const tools_1 = __webpack_require__(28);
exports.siblingPositions = ['only', 'eldest', 'middle', 'youngest'];
exports.siblingPositionType = (0, tools_1.literalStringArrayTyping)('SiblingPosition', [...exports.siblingPositions]);


/***/ }),
/* 55 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.siblingStateType = exports.siblings = void 0;
const tools_1 = __webpack_require__(28);
exports.siblings = ['none', 'one', 'two', 'three', 'four', 'five', 'more'];
exports.siblingStateType = (0, tools_1.literalStringArrayTyping)('SiblingState', [...exports.siblings]);


/***/ }),
/* 56 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.genderType = exports.genders = void 0;
const tools_1 = __webpack_require__(28);
exports.genders = ['male', 'female', 'diverse',];
exports.genderType = (0, tools_1.literalStringArrayTyping)('Gender', [...exports.genders]);


/***/ }),
/* 57 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.parentalSituationType = exports.parentalSituations = void 0;
const tools_1 = __webpack_require__(28);
exports.parentalSituations = ['parents', 'father', 'mother', 'other'];
exports.parentalSituationType = (0, tools_1.literalStringArrayTyping)('ParentalSituation', [
    ...exports.parentalSituations,
]);


/***/ }),
/* 58 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.dwellingSituationType = exports.dwellingSituations = void 0;
const tools_1 = __webpack_require__(28);
exports.dwellingSituations = ['city', 'town', 'suburb', 'small_town', 'country', 'village', 'other'];
exports.dwellingSituationType = (0, tools_1.literalStringArrayTyping)('DwellingSituation', [
    ...exports.dwellingSituations,
]);


/***/ }),
/* 59 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.homeMovesType = void 0;
const tools_1 = __webpack_require__(28);
const homeMoves = ['0', '1', '2', '2+'];
exports.homeMovesType = (0, tools_1.literalStringArrayTyping)('HomeMoves', [...homeMoves]);


/***/ }),
/* 60 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.stateIsEast = exports.germanStateType = exports.germanStates = void 0;
const tools_1 = __webpack_require__(28);
exports.germanStates = [
    'BB',
    'BE',
    'BW',
    'BY',
    'HB',
    'HE',
    'HH',
    'MV',
    'NI',
    'NW',
    'RP',
    'SH',
    'SL',
    'SN',
    'ST',
    'TH',
];
exports.germanStateType = (0, tools_1.literalStringArrayTyping)('GermanState', [...exports.germanStates]);
const stateIsEast = (s) => ['MV', 'BB', 'SN', 'ST', 'TH'].includes(s);
exports.stateIsEast = stateIsEast;


/***/ }),
/* 61 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(62), exports);
tslib_1.__exportStar(__webpack_require__(64), exports);
tslib_1.__exportStar(__webpack_require__(63), exports);


/***/ }),
/* 62 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DateOnlyInput = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const ymd_1 = __webpack_require__(63);
const dateToMidday = (input) => new Date(input.getFullYear(), input.getMonth(), input.getDate(), 12, 0, 0);
const isStringOrNumber = (input) => ['string', 'number'].includes(typeof input);
exports.DateOnlyInput = new t.Type('DateFromStringOrDateObject', (input) => input instanceof Date ||
    (typeof input === 'string' && !isNaN(Date.parse(input))) ||
    (typeof input === 'number' && !isNaN(new Date(input).valueOf())), (input, context) => {
    if (input instanceof Date)
        return t.success(dateToMidday(input));
    return isStringOrNumber(input)
        ? t.success(dateToMidday(new Date(input)))
        : t.failure(input, context, 'Input must be a number, Date instance or valid string date.');
}, ymd_1.ymd);


/***/ }),
/* 63 */
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ymd = void 0;
const ymd = (v) => `${v.getFullYear()}-${String(v.getMonth() + 1).padStart(2, '0')}-${String(v.getMonth() + 1).padStart(2, '0')}`;
exports.ymd = ymd;


/***/ }),
/* 64 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.withJSON = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const Either_1 = __webpack_require__(17);
function withJSON(codec) {
    return new t.Type(`withJSON(${codec.name})`, codec.is, (u, c) => {
        try {
            // Parse the JSON string before decoding
            const json = typeof u === 'string' ? JSON.parse(u) : u;
            return codec.validate(json, c);
        }
        catch (error) {
            return (0, Either_1.left)([
                {
                    value: u,
                    context: c,
                    message: error instanceof Error ? error.message : String(error),
                },
            ]);
        }
    }, (a) => JSON.stringify(codec.encode(a)));
}
exports.withJSON = withJSON;


/***/ }),
/* 65 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.createProfile = exports.ChildhoodC = exports.DonatedProfileC = exports.ChildhoodProfileC = exports.childhoodProfileProps = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const E = tslib_1.__importStar(__webpack_require__(17));
const childhood_situation_1 = __webpack_require__(53);
const nullableTranslatable_1 = __webpack_require__(66);
const io_ts_types_1 = __webpack_require__(40);
const function_1 = __webpack_require__(15);
const uuid_1 = __webpack_require__(68);
const item_1 = __webpack_require__(69);
exports.childhoodProfileProps = {
    hobby: t.union([t.null, t.string]),
    favoriteColor: t.union([t.null, t.string]),
    hatedFood: t.union([t.null, t.string]),
    softToy: t.union([t.null, t.string]),
    dwellingSituationComment: t.union([t.null, t.string]),
    ...item_1.searchableItems,
};
exports.ChildhoodProfileC = t.type(exports.childhoodProfileProps);
exports.DonatedProfileC = t.type({
    id: io_ts_types_1.UUID,
    legacyId: t.union([t.null, t.number]),
    situation: childhood_situation_1.ChildhoodSituationC,
    profile: (0, nullableTranslatable_1.NullableTranslatableC)(exports.ChildhoodProfileC)
});
// This is the DonatedProfile with at least one Item set.
exports.ChildhoodC = t.brand(t.type({ ...exports.DonatedProfileC.props, profile: (0, nullableTranslatable_1.TranslatableC)(exports.ChildhoodProfileC) }), (dp) => item_1.items.some((i) => dp.profile.de && dp.profile.de[i] != null), 'Childhood');
const createProfile = (payload) => {
    (0, function_1.pipe)(exports.DonatedProfileC.decode(payload), E.map((p) => ({ ...p, id: (0, uuid_1.v4)() })), E.chain(exports.ChildhoodC.decode));
};
exports.createProfile = createProfile;


/***/ }),
/* 66 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.NullableTranslatableC = exports.TranslatableC = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const language_1 = __webpack_require__(67);
const TranslatableC = (codec) => t.record(language_1.languageType.literals, codec);
exports.TranslatableC = TranslatableC;
const NullableTranslatableC = (codec) => t.record(language_1.languageType.literals, t.union([codec, t.null]));
exports.NullableTranslatableC = NullableTranslatableC;


/***/ }),
/* 67 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.languageType = exports.languages = void 0;
const tools_1 = __webpack_require__(28);
exports.languages = ['en', 'de'];
exports.languageType = (0, tools_1.literalStringArrayTyping)('Language', [...exports.languages]);


/***/ }),
/* 68 */
/***/ ((module) => {

module.exports = require("uuid");

/***/ }),
/* 69 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.itemsType = exports.items = exports.ItemC = exports.searchableItems = exports.ItemToggleValue = void 0;
const tslib_1 = __webpack_require__(4);
const tools_1 = __webpack_require__(28);
const book_1 = __webpack_require__(45);
const grandparents_1 = __webpack_require__(47);
const holiday_1 = __webpack_require__(48);
const party_1 = __webpack_require__(49);
const song_1 = __webpack_require__(50);
const audio_book_1 = __webpack_require__(26);
const t = tslib_1.__importStar(__webpack_require__(21));
const ReadonlyRecord_1 = __webpack_require__(70);
exports.ItemToggleValue = {
    book: 1,
    grandparents: 2,
    holidays: 4,
    memory: 8,
    party: 16,
    song: 32,
    audioBook: 64,
};
const nullable = (val) => t.union([t.null, val]);
exports.searchableItems = {
    memory: nullable(t.string),
    book: nullable(book_1.Book),
    grandparents: nullable(grandparents_1.Grandparents),
    holidays: nullable(holiday_1.Holiday),
    party: nullable(party_1.Party),
    song: nullable(song_1.Song),
    audioBook: nullable(audio_book_1.AudioBook)
};
exports.ItemC = t.keyof(exports.searchableItems);
exports.items = (0, ReadonlyRecord_1.keys)(exports.ItemToggleValue);
exports.itemsType = (0, tools_1.literalStringArrayTyping)('Item', Object.keys(exports.ItemToggleValue));


/***/ }),
/* 70 */
/***/ ((module) => {

module.exports = require("fp-ts/lib/ReadonlyRecord");

/***/ }),
/* 71 */
/***/ ((module) => {

module.exports = require("immutable");

/***/ }),
/* 72 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(73), exports);
tslib_1.__exportStar(__webpack_require__(74), exports);


/***/ }),
/* 73 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.eventTypeBuilder = exports.EventTypeC = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
exports.EventTypeC = t.type({ aggregateType: t.string, type: t.string });
const eventTypeBuilder = (aggregate) => (type, payload) => t.type({
    id: t.string,
    type: t.literal(type),
    aggregateId: t.string,
    aggregateType: t.literal(aggregate.name),
    aggregateVersion: t.refinement(t.number, (n) => Number.isInteger(n) && n > 0, 'PositiveInteger'),
    payload,
    timestamp: t.number,
});
exports.eventTypeBuilder = eventTypeBuilder;


/***/ }),
/* 74 */
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));


/***/ }),
/* 75 */
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getItemStatus = void 0;
const getItemStatus = (i) => ({
    book: i.book != null,
    grandparents: i.grandparents != null,
    holidays: i.holidays != null,
    memory: i.memory != null,
    party: i.party != null,
    song: i.song != null,
    audioBook: i.audioBook != null,
});
exports.getItemStatus = getItemStatus;


/***/ }),
/* 76 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MatchingItemsC = exports.MatchingItemsProps = exports.MatchingItemC = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const book_1 = __webpack_require__(45);
const grandparents_1 = __webpack_require__(47);
const holiday_1 = __webpack_require__(48);
const party_1 = __webpack_require__(49);
const song_1 = __webpack_require__(50);
const audio_book_1 = __webpack_require__(26);
const MatchingItemC = (codec) => t.type({ pid: t.number, weight: t.number, item: codec });
exports.MatchingItemC = MatchingItemC;
exports.MatchingItemsProps = {
    book: (0, exports.MatchingItemC)(book_1.Book),
    grandparents: (0, exports.MatchingItemC)(grandparents_1.Grandparents),
    holidays: (0, exports.MatchingItemC)(holiday_1.Holiday),
    memory: (0, exports.MatchingItemC)(t.string),
    party: (0, exports.MatchingItemC)(party_1.Party),
    song: (0, exports.MatchingItemC)(song_1.Song),
    audioBook: (0, exports.MatchingItemC)(audio_book_1.AudioBook),
};
exports.MatchingItemsC = t.type(exports.MatchingItemsProps);


/***/ }),
/* 77 */
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));


/***/ }),
/* 78 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(4);
tslib_1.__exportStar(__webpack_require__(79), exports);


/***/ }),
/* 79 */
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));


/***/ }),
/* 80 */
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.fMapping = void 0;
const fMapping = (name, col = name) => `'${name}', ${col}`;
exports.fMapping = fMapping;


/***/ }),
/* 81 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ChildhoodProfileTable = exports.ChildhoodSituationTableC = exports.ChildhoodProfileRequestTableC = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const model_1 = __webpack_require__(22);
const db_safe_string_1 = __webpack_require__(82);
const io_ts_types_1 = __webpack_require__(40);
const tools_1 = __webpack_require__(28);
const book_item_1 = __webpack_require__(84);
const party_item_1 = __webpack_require__(85);
const song_item_1 = __webpack_require__(86);
const audio_book_item_1 = __webpack_require__(88);
const base = {
    gender: model_1.genderType.fromNumber,
    siblings: model_1.siblingStateType.fromNumber,
    siblingPosition: model_1.siblingPositionType.fromNumber,
    bedroomSituation: model_1.bedroomSituationType.fromNumber,
    dwellingSituation: model_1.dwellingSituationType.fromNumber,
    moves: model_1.homeMovesType.fromNumber,
    parents: model_1.parentalSituationType.fromNumber,
};
exports.ChildhoodProfileRequestTableC = t.type({
    ...base,
    birthYear: (0, tools_1.numberInRange)(1900, new Date().getFullYear() - 10),
});
exports.ChildhoodSituationTableC = t.type({
    ...base,
    birthDate: io_ts_types_1.DateFromISOString,
});
exports.ChildhoodProfileTable = t.type({
    favoriteColor: t.union([t.null, db_safe_string_1.DbSafeString]),
    hobby: t.union([t.null, db_safe_string_1.DbSafeString]),
    hatedFood: t.union([t.null, db_safe_string_1.DbSafeString]),
    softToy: t.union([t.null, db_safe_string_1.DbSafeString]),
    dwellingSituationComment: t.union([t.null, db_safe_string_1.DbSafeString]),
    book: t.union([t.null, book_item_1.BookItem]),
    grandparents: t.union([t.null, model_1.Grandparents]),
    holidays: t.union([t.null, model_1.Holiday]),
    memory: t.union([t.null, t.string]),
    party: t.union([t.null, party_item_1.PartyItem]),
    song: t.union([t.null, song_item_1.SongItem]),
    audioBook: t.union([t.null, audio_book_item_1.AudioBookItem]),
});


/***/ }),
/* 82 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DbSafeString = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const mysql2_1 = __webpack_require__(83);
exports.DbSafeString = new t.Type('mysqlsafestring', t.string.is, t.string.validate, mysql2_1.escape);


/***/ }),
/* 83 */
/***/ ((module) => {

module.exports = require("mysql2");

/***/ }),
/* 84 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BookItem = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const model_1 = __webpack_require__(22);
exports.BookItem = t.type({
    title: t.string,
    author: t.string,
    character1: t.string,
    character2: t.string,
    synopsis: t.string,
    whyFavorite: t.string,
    howItInfluenced: t.string,
    ageWhenRead: model_1.childhoodAgeType.fromNumber,
    readBy: model_1.bookReadByType.fromNumber,
});


/***/ }),
/* 85 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.PartyItem = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const model_1 = __webpack_require__(22);
exports.PartyItem = t.type({ ...model_1.partyProps, likeParty: model_1.partyLikeType.fromNumber });


/***/ }),
/* 86 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SongTable = exports.SongItem = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const model_1 = __webpack_require__(22);
const person_item_table_1 = __webpack_require__(87);
exports.SongItem = t.type({ ...model_1.songProps, ageWhenImportant: model_1.childhoodAgeType.fromNumber });
exports.SongTable = t.intersection([person_item_table_1.PersonItemTable, exports.SongItem]);


/***/ }),
/* 87 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.PersonItemTable = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
exports.PersonItemTable = t.type({
    id: t.number,
    pid: t.number,
});


/***/ }),
/* 88 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AudioBookItem = void 0;
const io_ts_1 = __webpack_require__(21);
const model_1 = __webpack_require__(22);
exports.AudioBookItem = (0, io_ts_1.type)({ ...model_1.audioBookProps, ageWhenImportant: model_1.childhoodAgeType.fromNumber });


/***/ }),
/* 89 */
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.weights = void 0;
exports.weights = {
    birthYear: 5,
    bedroomSituation: 1,
    dwellingSituation: 1,
    parents: 1,
    siblingPosition: 1,
    siblings: 1,
    moves: 1,
    gender: 8,
};


/***/ }),
/* 90 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.itemQueryTable = void 0;
const book_item_1 = __webpack_require__(84);
const song_item_1 = __webpack_require__(86);
const model_1 = __webpack_require__(22);
const party_item_1 = __webpack_require__(85);
const audio_book_item_1 = __webpack_require__(88);
const item_join_query_1 = __webpack_require__(91);
exports.itemQueryTable = {
    audioBook: (0, item_join_query_1.itemJoinQuery)('audioBook', audio_book_item_1.AudioBookItem),
    book: (0, item_join_query_1.itemJoinQuery)('book', book_item_1.BookItem),
    grandparents: (0, item_join_query_1.itemJoinQuery)('grandparents', model_1.Grandparents),
    holidays: (0, item_join_query_1.itemJoinQuery)('holidays', model_1.Holiday),
    memory: `diverse`,
    song: (0, item_join_query_1.itemJoinQuery)('song', song_item_1.SongItem),
    party: (0, item_join_query_1.itemJoinQuery)('party', party_item_1.PartyItem),
};


/***/ }),
/* 91 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.itemJoinQuery = void 0;
const tslib_1 = __webpack_require__(4);
const function_1 = __webpack_require__(15);
const ReadonlyRecord_1 = __webpack_require__(92);
const A = tslib_1.__importStar(__webpack_require__(16));
const field_mapping_1 = __webpack_require__(80);
const itemJoinQuery = (item, type) => {
    return `json_object(${(0, function_1.pipe)(type.props, ReadonlyRecord_1.keys, A.map((k) => (0, field_mapping_1.fMapping)(k, `${k}`))).join(',')})`;
};
exports.itemJoinQuery = itemJoinQuery;


/***/ }),
/* 92 */
/***/ ((module) => {

module.exports = require("fp-ts/ReadonlyRecord");

/***/ }),
/* 93 */
/***/ ((module) => {

module.exports = require("rxjs");

/***/ }),
/* 94 */
/***/ ((module) => {

module.exports = require("io-ts/PathReporter");

/***/ }),
/* 95 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MemoryTable = void 0;
const tslib_1 = __webpack_require__(4);
const t = tslib_1.__importStar(__webpack_require__(21));
const person_item_table_1 = __webpack_require__(87);
const db_safe_string_1 = __webpack_require__(82);
exports.MemoryTable = t.intersection([person_item_table_1.PersonItemTable, t.type({ diverse: db_safe_string_1.DbSafeString })]);


/***/ }),
/* 96 */
/***/ ((module) => {

module.exports = require("express");

/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
var exports = __webpack_exports__;

Object.defineProperty(exports, "__esModule", ({ value: true }));
const common_1 = __webpack_require__(1);
const core_1 = __webpack_require__(2);
const app_module_1 = __webpack_require__(3);
async function bootstrap() {
    const app = await core_1.NestFactory.create(app_module_1.AppModule);
    const globalPrefix = 'api';
    app.setGlobalPrefix(globalPrefix);
    const port = process.env.PORT || 3000;
    await app.listen(port);
    common_1.Logger.log(`🚀 Application is running on: http://localhost:${port}/${globalPrefix}`);
}
bootstrap();

})();

/******/ })()
;
//# sourceMappingURL=main.js.map